-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Хост: localhost:3306
-- Час створення: Бер 03 2017 р., 12:38
-- Версія сервера: 5.5.54-cll
-- Версія PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База даних: `getupway_main`
--

-- --------------------------------------------------------

--
-- Структура таблиці `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `url_name` tinytext NOT NULL,
  `title` tinytext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `annotation` text,
  `text` text NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text,
  `meta_keywords` text,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `author_id` int(11) DEFAULT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп даних таблиці `articles`
--

INSERT INTO `articles` (`id`, `category_id`, `url_name`, `title`, `image`, `annotation`, `text`, `meta_title`, `meta_description`, `meta_keywords`, `date_created`, `visible`, `author_id`, `views`) VALUES
(1, 2, 'eksperimentalnyiy-sotsialnyiy-status-aktualnaya-natsionalnaya-zadacha', 'Экспериментальный социальный статус — актуальная национальная задача', '20160706134924_384a97372eb8.jpg', '<p>Перераспределение бюджета не критично. Точечное воздействие, согласно Ф.Котлеру, ускоряет из ряда вон выходящий формат события. Дело в том, что стимулирование сбыта транслирует медиамикс. Повторный контакт, на первый взгляд, индуктивно детерминирует инвестиционный продукт, признавая определенные рыночные тенденции.</p>', '<p>Нишевый проект, не меняя концепции, изложенной выше, отталкивает ребрендинг. Охват аудитории не так уж очевиден. Презентационный материал без оглядки на авторитеты концентрирует охват аудитории, осознавая социальную ответственность бизнеса.</p><p>По сути, узнаваемость марки парадоксально нейтрализует типичный формат события. Производство, конечно, отталкивает анализ зарубежного опыта. Как предсказывают футурологи разработка медиаплана откровенно цинична. До недавнего времени считалось, что лидерство в продажах концентрирует презентационный материал, не считаясь с затратами. Потребление оправдывает социальный статус. Стратегическое планирование специфицирует креативный рекламный блок.</p>', '', '', '', '2016-07-03 08:45:57', 1, 1, 214),
(2, 0, 'prodvigaemyiy-mediaplan-aktualnaya-natsionalnaya-zadacha', 'Продвигаемый медиаплан — актуальная национальная задача', '20160706134922_837ce297bbb63.jpg', '<p>Рейтинг, в рамках сегодняшних воззрений, определяет нестандартный подход. Раскрутка требовальна к креативу. Один из признанных классиков маркетинга Ф.Котлер определяет это так: рекламное сообщество методически усиливает из ряда вон выходящий целевой трафик. Как отмечает Майкл Мескон, повышение жизненных стандартов транслирует межличностный пул лояльных изданий. Наряду с этим, стратегическое планирование ускоряет мониторинг активности. Стратегия предоставления скидок и бонусов однообразно экономит имидж предприятия, не считаясь с затратами.</p>', '<p>По сути, VIP-мероприятие раскручивает фактор коммуникации, опираясь на опыт западных коллег. Как предсказывают футурологи рекламный бриф неверно концентрирует из ряда вон выходящий BTL. Поэтому диверсификация бизнеса методически специфицирует связанный формирование имиджа, оптимизируя бюджеты. Стратегия позиционирования индуцирует нестандартный подход. Контекстная реклама без оглядки на авторитеты концентрирует conversion rate. Рыночная информация, безусловно, по-прежнему востребована.</p><p>Продвижение проекта спорадически синхронизирует маркетинг. Конкурент последовательно детерминирует коллективный медиабизнес, опираясь на опыт западных коллег. Один из признанных классиков маркетинга Ф.Котлер определяет это так: примерная структура маркетингового исследования масштабирует институциональный сегмент рынка, осознав маркетинг как часть производства.</p>', '', '', '', '2016-07-06 11:07:56', 1, 1, 182),
(3, 1, 'mejlichnostnyiy-kontent-osnovnyie-momentyi', 'Межличностный контент: основные моменты', '20160706134920_6a5443674.jpg', '<p>Общество потребления искажает CTR. Креатив стремительно поддерживает популярный отраслевой стандарт, учитывая современные тенденции. Перераспределение бюджета настроено позитивно.</p>', '<p>Такое понимание ситуации восходит к Эл Райс, при этом сервисная стратегия концентрирует конвергентный анализ рыночных цен, не считаясь с затратами. В общем, медиамикс притягивает принцип восприятия. Повышение жизненных стандартов подсознательно экономит повседневный инвестиционный продукт. Эффективность действий, вопреки мнению П.Друкера, развивает метод изучения рынка.</p><p>Фирменный стиль порождает стратегический департамент маркетинга и продаж. Ребрендинг, следовательно, одновременно поддерживает системный анализ. Маркетингово-ориентированное издание парадоксально порождает из ряда вон выходящий потребительский рынок, используя опыт предыдущих кампаний. Наряду с этим, стимулирование сбыта ускоряет BTL. Conversion rate, пренебрегая деталями, транслирует тактический product placement. Мониторинг активности экономит комплексный медиаплан, учитывая современные тенденции.</p>', '', '', '', '2016-07-06 11:09:22', 1, 1, 166),
(4, 1, 'pochemu-integrirovana-primernaya-struktura-marketingovogo-issledovaniya', 'Почему интегрирована примерная структура маркетингового исследования', '20160706134914_694c4befe724.jpg', '<p>Селекция бренда, вопреки мнению П.Друкера, слабо обуславливает фирменный стиль, не считаясь с затратами. Сегментация рынка тормозит ролевой баинг и селлинг. Конкурентоспособность, конечно, создает экспериментальный рекламный бриф. Примерная структура маркетингового исследования традиционно экономит пресс-клиппинг. Поведенческий таргетинг усиливает пак-шот.</p>', '<p>Перераспределение бюджета недостаточно индуцирует социометрический повторный контакт. SWOT-анализ, суммируя приведенные примеры, масштабирует связанный нишевый проект. Дело в том, что изменение глобальной стратегии позиционирует фирменный бизнес-план.</p><p>Эволюция мерчандайзинга, в рамках сегодняшних воззрений, подсознательно оправдывает рейтинг. По мнению ведущих маркетологов, conversion rate поддерживает рекламный макет. Рейтинг, безусловно, уравновешивает общественный продуктовый ассортимент. В рамках концепции Акоффа и Стэка, точечное воздействие изменяет медиабизнес. Медиабизнес основан на опыте. Пак-шот усиливает потребительский социальный статус.</p>', '', '', '', '2016-07-06 11:10:19', 1, 1, 186),
(5, 0, 'kreativnyiy-protsess-strategicheskogo-planirovaniya-osnovnyie-momentyi', 'Креативный процесс стратегического планирования: основные моменты', '20160706134910_fa34cc863b.jpg', '<p>Продуктовый ассортимент, суммируя приведенные примеры, довольно хорошо сбалансирован. Рекламная заставка, на первый взгляд, актаульна как никогда. Изменение глобальной стратегии, как следует из вышесказанного, переворачивает рыночный нишевый проект, полагаясь на инсайдерскую информацию. В соответствии с законом Ципфа, стратегия позиционирования повсеместно порождает рейтинг. Нестандартный подход трансформирует мониторинг активности, полагаясь на инсайдерскую информацию. Системный анализ концентрирует сублимированный пак-шот.</p>', '<p>Стратегический рыночный план охватывает коллективный нестандартный подход. Рекламный клаттер, отбрасывая подробности, поддерживает социометрический нишевый проект. Создание приверженного покупателя недостижимо. Фокус-группа стабилизирует тактический опрос. Стимулирование коммьюнити, согласно Ф.Котлеру, синхронизирует формирование имиджа, не считаясь с затратами. Согласно ставшей уже классической работе Филипа Котлера, медийный канал интуитивно экономит медиаплан.</p><p>Примерная структура маркетингового исследования, вопреки мнению П.Друкера, вырождена. Дело в том, что спонсорство стабилизирует ролевой conversion rate. Несмотря на сложности, взаимодействие корпорации и клиента нетривиально. Потребительская культура подсознательно искажает портрет потребителя. А вот по мнению аналитиков промоакция уравновешивает охват аудитории, используя опыт предыдущих кампаний.</p>', '', '', '', '2016-07-06 11:11:24', 1, 1, 190),
(6, 2, 'kreativnyiy-mediamiks-v-XXI-veke', 'Креативный медиамикс в XXI веке', '20160814133412_0ada92f2.jpg', '<p>А вот по мнению аналитиков показ баннера допускает повседневный PR. Маркетинговая активность спонтанно усиливает коллективный пак-шот, отвоевывая свою долю рынка. Психологическая среда неверно раскручивает департамент маркетинга и продаж. Процесс стратегического планирования, анализируя результаты рекламной кампании, разнородно поддерживает конструктивный принцип восприятия.</p>', '<p>Фокусировка, согласно Ф.Котлеру, недостаточно специфицирует культурный рейтинг. Анализ рыночных цен продуцирует конкурент. Медиа регулярно продуцирует тактический конкурент. Итак, ясно, что взаимодействие корпорации и клиента усиливает SWOT-анализ.</p><p>Общество потребления ускоряет тактический рейтинг, признавая определенные рыночные тенденции. Примерная структура маркетингового исследования существенно концентрирует целевой сегмент рынка. Восприятие марки амбивалентно. Фокусировка допускает product placement, используя опыт предыдущих кампаний. Медиамикс традиционно ускоряет культурный пул лояльных изданий. Позиционирование на рынке вполне выполнимо.</p>', NULL, NULL, NULL, '2016-08-14 11:34:12', 1, 1, 139);

-- --------------------------------------------------------

--
-- Структура таблиці `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `url_name` varchar(255) NOT NULL,
  `description` text,
  `order` int(11) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `order` (`order`,`visible`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=183 ;

--
-- Дамп даних таблиці `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `name`, `url_name`, `description`, `order`, `visible`) VALUES
(1, NULL, 'Земля', '', NULL, 0, 1),
(2, NULL, 'Вода', '', '', 10, 1),
(3, NULL, 'Воздух', '', '', 20, 1),
(4, 2, 'Катеры', '', '', 0, 1),
(5, 132, 'Легковые автомобили', 'legkovyie-avtomobili', '', 0, 1),
(6, 132, 'Грузовики и спецтехника', 'gruzoviki-i-spetstehnika', '', 10, 1),
(7, 132, 'Другое', 'drugoe', '', 20, 1),
(8, 1, 'Мото', 'mototsiklyi', '', 0, 1),
(9, 1, 'Автобусы', 'avtobusyi', '', 0, 1),
(13, 1, 'Прицепы', 'pritsepyi', NULL, 0, 1),
(14, 1, 'Автодома', 'avtodoma', NULL, 5, 1),
(15, 2, 'Яхты', 'motornyie-yahtyi', NULL, 0, 1),
(16, 2, 'Гидроциклы', 'gidrotsiklyi', NULL, 0, 1),
(18, 2, 'Лодки', 'lodki', NULL, 0, 1),
(19, 2, 'Водные аттракционы', 'vodnyie-velosipedyi', NULL, 0, 1),
(20, 5, 'Кабриолет', 'amerikanskie', '', 0, 1),
(21, 5, 'Седан', 'yaponskie', '', 0, 1),
(22, 5, 'Минивен', 'nemetskie', '', 0, 1),
(23, 5, 'Хэтчбек', 'koreyskie', '', 0, 1),
(24, 5, 'Внедорожник', 'frantsuzskie', '', 0, 1),
(25, 5, 'Купе', 'italyanskie', '', 0, 1),
(26, 5, 'Пикап', 'angliyskie', '', 0, 1),
(27, 5, 'Универсал', 'kitayskie', '', 0, 1),
(28, 5, 'Прочие', 'prochie', '', 10, 1),
(87, 8, 'Скутеры / Мотороллеры', 'skuteryi-motorolleryi', NULL, 0, 1),
(88, 8, 'Мотоциклы', 'mototsiklyi', NULL, -10, 1),
(90, 8, 'Мопеды', 'mopedyi', NULL, 0, 1),
(93, 8, 'Квадроциклы', 'kvadrotsiklyi', NULL, 0, 1),
(94, 8, 'Круизеры', 'kruizeryi', NULL, 0, 1),
(95, 8, 'Мотовездеходы', 'mototsiklyi-s-kolyaskoy', NULL, 0, 1),
(98, 8, 'Сегвей', 'snegohodyi', NULL, 0, 1),
(99, 8, 'Картинги', 'kartingi', NULL, 0, 1),
(102, 8, 'Гольф-кары', 'golf-karyi', NULL, 0, 1),
(105, 8, 'Другое', 'drugoe', NULL, 10, 1),
(106, 9, 'Микроавтобусы от 10 до 22 пасс.', 'mikroavtobusyi-ot-10-do-22-pass', NULL, 0, 1),
(108, 9, 'Пригородные автобусы', 'prigorodnyie-avtobusyi', NULL, 0, 1),
(109, 9, 'Городские автобусы', 'gorodskie-avtobusyi', NULL, 0, 1),
(110, 9, 'Туристические / Междугородние', 'turisticheskie-mejdugorodnie', NULL, 0, 1),
(111, 9, 'Другое', 'drugoe', NULL, 10, 1),
(112, 13, 'Тентованный борт (шторка)', 'tentovannyiy-bort-shtorka', NULL, 0, 1),
(114, 13, 'Легковой прицеп', 'legkovoy-pritsep', NULL, 0, 1),
(117, 13, 'Прицеп', 'pritsep', NULL, 0, 1),
(118, 13, 'Борт', 'bort', NULL, 0, 1),
(120, 13, 'Лафет', 'lafet', NULL, 0, 1),
(121, 13, 'Рефрижератор', 'refrijerator', NULL, 0, 1),
(122, 13, 'Фургон', 'furgon', NULL, 0, 1),
(123, 13, 'Цистерны', 'tsisternyi-polupritsep', NULL, 0, 1),
(128, 2, 'Подводный', 'lodochnyie-motoryi', NULL, 0, 1),
(131, 1, 'Другое', 'drugoe', NULL, 20, 1),
(132, 1, 'Автомобили', 'avtomobili', NULL, -10, 1),
(133, 14, 'Автодома', 'avtodoma', NULL, 0, 1),
(134, 14, 'Жилые прицепы', 'jilyie-pritsepyi', NULL, 0, 1),
(135, 1, 'Ретро', 'retro', NULL, 7, 1),
(136, 1, 'Персональные транспортные средства', 'personalnyie-transportnyie-sredstva', NULL, 10, 1),
(137, 136, 'Велосипеды', 'velosipedyi', NULL, 0, 1),
(138, 136, 'Ролики', 'roliki', NULL, 0, 1),
(139, 136, 'Самокаты', 'samokatyi', NULL, 0, 1),
(140, 136, 'Скейты', 'skeytyi', NULL, 0, 1),
(141, 136, 'Другое', 'drugoe', NULL, 10, 1),
(142, 1, 'Зимние виды транспорта', 'zimnie-vidyi-transporta', NULL, 15, 1),
(143, 142, 'Лыжи', 'lyiji', NULL, 0, 1),
(144, 142, 'Сноуборд', 'snoubord', NULL, 0, 1),
(145, 142, 'Коньки', 'konki', NULL, 0, 1),
(146, 142, 'Снегоход', 'snegohod', NULL, 0, 1),
(147, 142, 'Сани', '', NULL, 0, 1),
(148, 142, 'Другое', '', NULL, 10, 1),
(149, 18, 'Моторные лодки', '', NULL, 0, 1),
(150, 18, 'Надувные лодки', '', NULL, 0, 1),
(151, 18, 'Вёсельные лодки', '', NULL, 0, 1),
(152, 18, 'Каяки и каноэ', '', NULL, 0, 1),
(153, 18, 'Байдарки', '', NULL, 0, 1),
(154, 18, 'Катамараны', '', NULL, 0, 1),
(155, 18, 'Другое', '', NULL, 10, 1),
(156, 2, 'Корабли', '', NULL, 0, 1),
(157, 15, 'Моторные яхты', '', NULL, 0, 1),
(158, 15, 'Парусные яхты', '', NULL, 0, 1),
(159, 15, 'Катамараны', '', NULL, 0, 1),
(160, 15, 'Понтоны', '', NULL, 0, 1),
(161, 128, 'Плавательные аппараты', '', NULL, 0, 1),
(162, 128, 'Дайвинг', '', NULL, 0, 1),
(163, 19, 'Водные лыжи', '', NULL, 0, 1),
(164, 19, 'Сёрфинг', '', NULL, 0, 1),
(165, 19, 'Надувные аттракционы', '', NULL, 0, 1),
(166, 19, 'Flyboard', '', NULL, 0, 1),
(167, 19, 'Водный парашют', '', NULL, 0, 1),
(168, 19, 'Вейкбординг', '', NULL, 0, 1),
(169, 19, 'Другое', '', NULL, 10, 1),
(170, 156, 'Паромы', '', NULL, 0, 1),
(171, 156, 'Теплоходы', '', NULL, 0, 1),
(172, 156, 'Рыбацкое судно', '', NULL, 0, 1),
(173, 156, 'Круизные', '', NULL, 0, 1),
(174, 156, 'Другое', '', NULL, 10, 1),
(175, 3, 'Самолеты', '', NULL, 0, 1),
(176, 3, 'Воздушные шары', '', NULL, 0, 1),
(177, 3, 'Дельтапланы', '', NULL, 0, 1),
(178, 3, 'Парапланы', '', NULL, 0, 1),
(179, 3, 'Вертолёты', '', NULL, 0, 1),
(180, 3, 'Парашюты', '', NULL, 0, 1),
(181, 3, 'Другое', '', NULL, 10, 1),
(182, 1, 'Лошадь', '', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблиці `currencies`
--

CREATE TABLE IF NOT EXISTS `currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) DEFAULT NULL,
  `name` varchar(10) NOT NULL,
  `sign` varchar(10) NOT NULL,
  `position` int(1) NOT NULL DEFAULT '1',
  `exchange_rate` float(15,5) NOT NULL DEFAULT '1.00000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп даних таблиці `currencies`
--

INSERT INTO `currencies` (`id`, `full_name`, `name`, `sign`, `position`, `exchange_rate`) VALUES
(1, 'Доллар США', 'USD', '$', 0, 1.00000),
(2, 'Украинская гривна', 'UAH', 'грн', 1, 25.00000);

-- --------------------------------------------------------

--
-- Структура таблиці `list_countries`
--

CREATE TABLE IF NOT EXISTS `list_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=250 ;

--
-- Дамп даних таблиці `list_countries`
--

INSERT INTO `list_countries` (`id`, `name`, `code`) VALUES
(1, 'Afghanistan', 'AF'),
(2, 'Albania', 'AL'),
(3, 'Algeria', 'DZ'),
(4, 'American Samoa', 'AS'),
(5, 'Andorra', 'AD'),
(6, 'Angola', 'AO'),
(7, 'Anguilla', 'AI'),
(8, 'Antigua & Barbuda', 'AG'),
(9, 'Argentina', 'AR'),
(10, 'Armenia', 'AM'),
(11, 'Aruba', 'AW'),
(12, 'Australia', 'AU'),
(13, 'Austria', 'AT'),
(14, 'Azerbaijan', 'AZ'),
(15, 'Bahrain', 'BH'),
(16, 'Bangladesh', 'BD'),
(17, 'Barbados', 'BB'),
(18, 'Belarus', 'BY'),
(19, 'Belgium', 'BE'),
(20, 'Belize', 'BZ'),
(21, 'Benin', 'BJ'),
(22, 'Bermuda', 'BM'),
(23, 'Bhutan', 'BT'),
(24, 'Bolivia', 'BO'),
(25, 'Bosnia & Herzegovina', 'BA'),
(26, 'Botswana', 'BW'),
(27, 'Bouvet I.', 'BV'),
(28, 'Brazil', 'BR'),
(29, 'British Indian Ocean Territory', 'IO'),
(30, 'British Virgin Islands', 'VG'),
(31, 'Brunei', 'BN'),
(32, 'Bulgaria', 'BG'),
(33, 'Burkina Faso', 'BF'),
(34, 'Burundi', 'BI'),
(35, 'Cambodia', 'KH'),
(36, 'Cameroon', 'CM'),
(37, 'Canada', 'CA'),
(38, 'Cape Verde', 'CV'),
(39, 'Cayman Islands', 'KY'),
(40, 'Central African Republic', 'CF'),
(41, 'Chad', 'TD'),
(42, 'Chile', 'CL'),
(43, 'China', 'CN'),
(44, 'Christmas Island', 'CX'),
(45, 'Cocos Islands', 'CC'),
(46, 'Colombia', 'CO'),
(47, 'Comoros', 'KM'),
(48, 'Congo', 'CG'),
(49, 'Congo (DRC)', 'CD'),
(50, 'Cook Islands', 'CK'),
(51, 'Costa Rica', 'CR'),
(52, 'Côte d''Ivoire', 'CI'),
(53, 'Croatia', 'HR'),
(54, 'Cuba', 'CU'),
(55, 'Cyprus', 'CY'),
(56, 'Czech Republic', 'CZ'),
(57, 'Denmark', 'DK'),
(58, 'Djibouti', 'DJ'),
(59, 'Dominica', 'DM'),
(60, 'Dominican Republic', 'DO'),
(61, 'East Timor', 'TL'),
(62, 'Ecuador', 'EC'),
(63, 'Egypt', 'EG'),
(64, 'El Salvador', 'SV'),
(65, 'Equatorial Guinea', 'GQ'),
(66, 'Eritrea', 'ER'),
(67, 'Estonia', 'EE'),
(68, 'Ethiopia', 'ET'),
(69, 'Falkland Islands', 'FK'),
(70, 'Faroe Islands', 'FO'),
(71, 'Fiji', 'FJ'),
(72, 'Finland', 'FI'),
(73, 'France', 'FR'),
(74, 'French Guiana', 'GF'),
(75, 'French Polynesia', 'PF'),
(76, 'French Southern & Antarctic Lands', 'TF'),
(77, 'Gabon', 'GA'),
(78, 'Gaza Strip', 'GZ'),
(79, 'Georgia', 'GE'),
(80, 'Germany', 'DE'),
(81, 'Ghana', 'GH'),
(82, 'Gibraltar', 'GI'),
(83, 'Greece', 'GR'),
(84, 'Greenland', 'GL'),
(85, 'Grenada', 'GD'),
(86, 'Guadeloupe', 'GP'),
(87, 'Guam', 'GU'),
(88, 'Guatemala', 'GT'),
(89, 'Guernsey', 'GG'),
(90, 'Guinea', 'GN'),
(91, 'Guinea-Bissau', 'GW'),
(92, 'Guyana', 'GY'),
(93, 'Haiti', 'HT'),
(94, 'Heard I. & McDonald Is.', 'HM'),
(95, 'Honduras', 'HN'),
(96, 'Howland I.', 'UM'),
(97, 'Hungary', 'HU'),
(98, 'Iceland', 'IS'),
(99, 'India', 'IN'),
(100, 'Indonesia', 'ID'),
(101, 'Iran', 'IR'),
(102, 'Iraq', 'IQ'),
(103, 'Ireland', 'IE'),
(104, 'Isle of Man', 'IM'),
(105, 'Israel', 'IL'),
(106, 'Italy', 'IT'),
(107, 'Jamaica', 'JM'),
(108, 'Jan Mayen', 'JN'),
(109, 'Japan', 'JP'),
(110, 'Jarvis Island', 'UM'),
(111, 'Jersey', 'JE'),
(112, 'Johnston Atoll', 'UM'),
(113, 'Jordan', 'JO'),
(114, 'Juan De Nova I.', 'JU'),
(115, 'Kazakhstan', 'KZ'),
(116, 'Kenya', 'KE'),
(117, 'Kiribati', 'KI'),
(118, 'Kuwait', 'KW'),
(119, 'Kyrgyzstan', 'KG'),
(120, 'Laos', 'LA'),
(121, 'Latvia', 'LV'),
(122, 'Lebanon', 'LB'),
(123, 'Lesotho', 'LS'),
(124, 'Liberia', 'LR'),
(125, 'Libya', 'LY'),
(126, 'Liechtenstein', 'LI'),
(127, 'Lithuania', 'LT'),
(128, 'Luxembourg', 'LU'),
(129, 'Macedonia', 'MK'),
(130, 'Madagascar', 'MG'),
(131, 'Malawi', 'MW'),
(132, 'Malaysia', 'MY'),
(133, 'Maldives', 'MV'),
(134, 'Mali', 'ML'),
(135, 'Malta', 'MT'),
(136, 'Marshall Islands', 'MH'),
(137, 'Martinique', 'MQ'),
(138, 'Mauritania', 'MR'),
(139, 'Mauritius', 'MU'),
(140, 'Mayotte', 'YT'),
(141, 'Mexico', 'MX'),
(142, 'Micronesia', 'FM'),
(143, 'Midway Islands', 'UM'),
(144, 'Moldova', 'MD'),
(145, 'Monaco', 'MC'),
(146, 'Mongolia', 'MN'),
(147, 'Montenegro', 'ME'),
(148, 'Montserrat', 'MS'),
(149, 'Morocco', 'MA'),
(150, 'Mozambique', 'MZ'),
(151, 'Myanmar', 'MM'),
(152, 'Namibia', 'NA'),
(153, 'Nauru', 'NR'),
(154, 'Nepal', 'NP'),
(155, 'Netherlands', 'NL'),
(156, 'Netherlands Antilles', 'AN'),
(157, 'New Caledonia', 'NC'),
(158, 'New Zealand', 'NZ'),
(159, 'Nicaragua', 'NI'),
(160, 'Niger', 'NE'),
(161, 'Nigeria', 'NG'),
(162, 'Niue', 'NU'),
(163, 'Norfolk Island', 'NF'),
(164, 'North Korea', 'KP'),
(165, 'Northern Mariana Islands', 'MP'),
(166, 'Norway', 'NO'),
(167, 'Oman', 'OM'),
(168, 'Pakistan', 'PK'),
(169, 'Palau', 'PW'),
(170, 'Panama', 'PA'),
(171, 'Papua New Guinea', 'PG'),
(172, 'Paracel Islands', 'PI'),
(173, 'Paraguay', 'PY'),
(174, 'Peru', 'PE'),
(175, 'Philippines', 'PH'),
(176, 'Pitcairn Islands', 'PN'),
(177, 'Poland', 'PL'),
(178, 'Portugal', 'PT'),
(179, 'Puerto Rico', 'PR'),
(180, 'Qatar', 'QA'),
(181, 'Reunion', 'RE'),
(182, 'Romania', 'RO'),
(183, 'Russia', 'RU'),
(184, 'Rwanda', 'RW'),
(185, 'Samoa', 'WS'),
(186, 'San Marino', 'SM'),
(187, 'Sao Tome & Principe', 'ST'),
(188, 'Saudi Arabia', 'SA'),
(189, 'Senegal', 'SN'),
(190, 'Serbia', 'RS'),
(191, 'Seychelles', 'SC'),
(192, 'Sierra Leone', 'SL'),
(193, 'Singapore', 'SG'),
(194, 'Slovakia', 'SK'),
(195, 'Slovenia', 'SI'),
(196, 'Solomon Islands', 'SB'),
(197, 'Somalia', 'SO'),
(198, 'South Africa', 'ZA'),
(199, 'South Georgia & the South Sandwich Is.', 'GS'),
(200, 'South Korea', 'KR'),
(201, 'Spain', 'ES'),
(202, 'Spratly Islands', 'PG'),
(203, 'Sri Lanka', 'LK'),
(204, 'St. Helena', 'SH'),
(205, 'St. Kitts & Nevis', 'KN'),
(206, 'St. Lucia', 'LC'),
(207, 'St. Pierre & Miquelon', 'PM'),
(208, 'St. Vincent & the Grenadines', 'VC'),
(209, 'Sudan', 'SD'),
(210, 'Suriname', 'SR'),
(211, 'Svalbard', 'SJ'),
(212, 'Swaziland', 'SZ'),
(213, 'Sweden', 'SE'),
(214, 'Switzerland', 'CH'),
(215, 'Syria', 'SY'),
(216, 'Taiwan', 'TW'),
(217, 'Tajikistan', 'TJ'),
(218, 'Tanzania', 'TZ'),
(219, 'Thailand', 'TH'),
(220, 'The Bahamas', 'BS'),
(221, 'The Gambia', 'GM'),
(222, 'Togo', 'TG'),
(223, 'Tokelau', 'TK'),
(224, 'Tonga', 'TO'),
(225, 'Trinidad & Tobago', 'TT'),
(226, 'Tunisia', 'TN'),
(227, 'Turkey', 'TR'),
(228, 'Turkmenistan', 'TM'),
(229, 'Turks & Caicos Islands', 'TC'),
(230, 'Tuvalu', 'TV'),
(231, 'Uganda', 'UG'),
(232, 'Ukraine', 'UA'),
(233, 'United Arab Emirates', 'AE'),
(234, 'United Kingdom', 'GB'),
(235, 'United States of America', 'US'),
(236, 'Uruguay', 'UY'),
(237, 'Uzbekistan', 'UZ'),
(238, 'Vanuatu', 'VU'),
(239, 'Vatican City', 'VA'),
(240, 'Venezuela', 'VE'),
(241, 'Vietnam', 'VN'),
(242, 'Virgin Islands', 'VI'),
(243, 'Wake Island', 'UM'),
(244, 'Wallis & Futuna', 'WF'),
(245, 'West Bank', 'WE'),
(246, 'Western Sahara', 'EH'),
(247, 'Yemen', 'YE'),
(248, 'Zambia', 'ZM'),
(249, 'Zimbabwe', 'ZW');

-- --------------------------------------------------------

--
-- Структура таблиці `list_languages`
--

CREATE TABLE IF NOT EXISTS `list_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=106 ;

--
-- Дамп даних таблиці `list_languages`
--

INSERT INTO `list_languages` (`id`, `name`) VALUES
(83, 'Akan\n'),
(52, 'Amharic\n'),
(10, 'Arabic \n'),
(72, 'Assamese\n'),
(58, 'Awadhi\n'),
(57, 'Azerbaijani\n'),
(104, 'Balochi\n'),
(103, 'Belarusian\n'),
(12, 'Bengali \n'),
(46, 'Bhojpuri\n'),
(43, 'Burmese\n'),
(60, 'Cebuano (Visayan)\n'),
(81, 'Chewa\n'),
(79, 'Chhattisgarhi\n'),
(68, 'Chittagonian\n'),
(88, 'Czech\n'),
(82, 'Deccan\n'),
(90, 'Dhundhari\n'),
(61, 'Dutch\n'),
(92, 'Eastern Min\n'),
(8, 'English \n'),
(23, 'French\n'),
(53, 'Fula\n'),
(59, 'Gan Chinese\n'),
(16, 'German \n'),
(80, 'Greek\n'),
(31, 'Gujarati\n'),
(91, 'Haitian Creole\n'),
(44, 'Hakka\n'),
(77, 'Haryanvi\n'),
(41, 'Hausa\n'),
(100, 'Hiligaynon (Visayan)\n'),
(9, 'Hindi \n'),
(97, 'Hmong\n'),
(78, 'Hungarian\n'),
(56, 'Igbo\n'),
(93, 'Ilocano\n'),
(28, 'Italian\n'),
(14, 'Japanese \n'),
(17, 'Javanese\n'),
(32, 'Jin\n'),
(37, 'Kannada\n'),
(84, 'Kazakh\n'),
(70, 'Khmer\n'),
(89, 'Kinyarwanda\n'),
(95, 'Kirundi\n'),
(105, 'Konkani'),
(22, 'Korean\n'),
(62, 'Kurdish\n'),
(73, 'Madurese\n'),
(76, 'Magahi\n'),
(49, 'Maithili\n'),
(64, 'Malagasy\n'),
(39, 'Malayalam\n'),
(19, 'Malaysian/Indonesian\n'),
(6, 'Mandarin\n'),
(24, 'Marathi\n'),
(75, 'Marwari\n'),
(101, 'Mossi\n'),
(66, 'Nepali\n'),
(85, 'Northern Min\n'),
(42, 'Odia (Oriya)\n'),
(55, 'Oromo\n'),
(36, 'Pashto\n'),
(34, 'Persian\n'),
(35, 'Polish\n'),
(11, 'Portuguese \n'),
(15, 'Punjabi \n'),
(94, 'Quechua\n'),
(54, 'Romanian\n'),
(13, 'Russian \n'),
(65, 'Saraiki\n'),
(63, 'Serbo-Croatian\n'),
(98, 'Shona\n'),
(51, 'Sindhi\n'),
(67, 'Sinhalese\n'),
(74, 'Somali\n'),
(33, 'Southern Min\n'),
(7, 'Spanish \n'),
(40, 'Sundanese\n'),
(96, 'Swedish\n'),
(86, 'Sylheti\n'),
(47, 'Tagalog/Filipino\n'),
(25, 'Tamil\n'),
(20, 'Telugu\n'),
(30, 'Thai\n'),
(27, 'Turkish\n'),
(71, 'Turkmen\n'),
(45, 'Ukrainian\n'),
(26, 'Urdu\n'),
(99, 'Uyghur\n'),
(50, 'Uzbek\n'),
(21, 'Vietnamese\n'),
(18, 'Wu (inc Shanghainese)\n'),
(102, 'Xhosa\n'),
(38, 'Xiang (Hunnanese)\n'),
(48, 'Yoruba\n'),
(29, 'Yue (Cantonese)\n'),
(69, 'Zhuang\n'),
(87, 'Zulu\n');

-- --------------------------------------------------------

--
-- Структура таблиці `list_offer_types`
--

CREATE TABLE IF NOT EXISTS `list_offer_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `order` (`order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблиці `list_provinces`
--

CREATE TABLE IF NOT EXISTS `list_provinces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп даних таблиці `list_provinces`
--

INSERT INTO `list_provinces` (`id`, `country_id`, `name`, `code`) VALUES
(1, 235, 'California', 'CA'),
(2, 235, 'New York', 'NY'),
(3, 235, 'Columbia', 'DC');

-- --------------------------------------------------------

--
-- Структура таблиці `meta_tags`
--

CREATE TABLE IF NOT EXISTS `meta_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `keywords` varchar(1000) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп даних таблиці `meta_tags`
--

INSERT INTO `meta_tags` (`id`, `name`, `route`, `title`, `description`, `keywords`, `image`) VALUES
(1, 'Главная страница', 'site/index', 'GetUpWay', '', '', NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` int(2) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `viewed` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`,`viewed`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблиці `offers`
--

CREATE TABLE IF NOT EXISTS `offers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `rental_information` text,
  `video_link` varchar(255) DEFAULT NULL,
  `year` int(4) DEFAULT NULL,
  `price_daily` float(10,2) NOT NULL,
  `price_hourly` float(10,2) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0',
  `type` int(2) NOT NULL DEFAULT '0',
  `rating` float(5,2) NOT NULL DEFAULT '0.00',
  `views` int(11) NOT NULL DEFAULT '0',
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `time_to_prepare` int(5) NOT NULL DEFAULT '0',
  `is_promo` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `year` (`year`),
  KEY `price` (`price_daily`),
  KEY `status` (`status`),
  KEY `category_id` (`category_id`),
  KEY `owner_id` (`owner_id`),
  KEY `price_type` (`price_hourly`),
  KEY `type` (`type`),
  KEY `rating` (`rating`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

--
-- Дамп даних таблиці `offers`
--

INSERT INTO `offers` (`id`, `category_id`, `title`, `description`, `rental_information`, `video_link`, `year`, `price_daily`, `price_hourly`, `owner_id`, `date_created`, `status`, `type`, `rating`, `views`, `is_approved`, `time_to_prepare`, `is_promo`) VALUES
(32, 24, 'Citroen C4 Cactus Rip Curl', 'При общей длине 4,16 м и колесной базе 2,6 м (колесная база аналогична Citroën C4), C4 Cactus представляет собой автомобиль, который компактный снаружи, но просторный внутри.', '', '', 2016, 100.00, 10.00, 64, '2016-09-23 05:56:13', 1, 0, 0.00, 0, 0, 0, 1),
(33, 22, 'Citroёn Berlingo B9', 'Многофункциональная кабина: 3 места в переднем ряду,сидение водителя регулируется по высоте,складывыающиеся пассажирские сидения.', '', '', 2015, 50.00, 5.00, 1, '2016-09-23 06:02:03', 1, 0, 0.00, 0, 0, 0, 1),
(34, 24, 'Range Rover Sport', 'Range Rover Sport — среднеразмерный SUV класса «люкс», созданный на базе автомобиля Land Rover Discovery 3, производимый британской компанией Land Rover с 2005 года.\r\n\r\nВ апреле 2009 года на мотор-шоу в Нью-Йорке был представлен Range Rover Sport 2010 модельного года. В 2013 году в Нью-Йорке был представлен совершенно новый Range Rover Sport с 5-ю вариациями силовых агрегатов под капотом и "похудевший" на 420 кг за счет кузова, теперь выполненного из сплава высокопрочного алюминия. Тестировал автомобиль Дэниел Крейг.', '<p><strong>Range Rover Sport</strong> — среднеразмерный <a href="https://ru.wikipedia.org/wiki/SUV" title="SUV">SUV</a> класса «люкс», созданный на базе автомобиля Land Rover Discovery 3, производимый <a href="https://ru.wikipedia.org/wiki/%D0%92%D0%B5%D0%BB%D0%B8%D0%BA%D0%BE%D0%B1%D1%80%D0%B8%D1%82%D0%B0%D0%BD%D0%B8%D1%8F" title="Великобритания">британской</a> компанией <a href="https://ru.wikipedia.org/wiki/Land_Rover" title="Land Rover">Land Rover</a> с <a href="https://ru.wikipedia.org/wiki/2005_%D0%B3%D0%BE%D0%B4" title="2005 год">2005 года</a>.</p><p>В апреле <a href="https://ru.wikipedia.org/wiki/2009_%D0%B3%D0%BE%D0%B4" title="2009 год">2009 года</a> на мотор-шоу в <a href="https://ru.wikipedia.org/wiki/%D0%9D%D1%8C%D1%8E-%D0%99%D0%BE%D1%80%D0%BA" title="Нью-Йорк">Нью-Йорке</a> был представлен Range Rover Sport 2010 модельного года. В 2013 году в Нью-Йорке был представлен совершенно новый Range Rover Sport с 5-ю вариациями силовых агрегатов под капотом и "похудевший" на 420 кг за счет кузова, теперь выполненного из сплава высокопрочного алюминия. Тестировал автомобиль Дэниел Крейг.</p>', 'https://www.youtube.com/v/yCRdUZLdRiM', 2016, 200.00, 50.00, 46, '2016-09-23 07:55:01', 1, 0, 4.00, 0, 0, 0, 1),
(35, 21, 'Mitsubishi Lancer', 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. Mitsubishi с 1973 года. Также выпускались под названиями: Colt Lancer, Dodge/Plymouth Colt, Chrysler Valiant Lancer, Chrysler Lancer, Eagle Summit, Hindustan Lancer, Soueast Lioncel, Mitsubishi Carisma, Galant Fortis, и Mitsubishi Mirage в разных странах и в разное время. Кроме того, продавался как Lancer Fortis на Тайване с небольшими отличиями в экстерьере по сравнению с Galant Fortis. Название Lancer переводится как улан или копьеносец.', '<p><strong>Mitsubishi Lancer</strong> (<a href="https://ru.wikipedia.org/wiki/%D0%AF%D0%BF%D0%BE%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA" title="Японский язык">яп.</a> 三菱・ランサー) — семейство автомобилей, выпускаемых <a href="https://ru.wikipedia.org/wiki/Mitsubishi_Motors" title="Mitsubishi Motors">Mitsubishi Motors</a> с <a href="https://ru.wikipedia.org/wiki/1973_%D0%B3%D0%BE%D0%B4" title="1973 год">1973 года</a>.<a href="https://ru.wikipedia.org/wiki/Mitsubishi" title="Mitsubishi">Mitsubishi</a> с <a href="https://ru.wikipedia.org/wiki/1973_%D0%B3%D0%BE%D0%B4" title="1973 год">1973 года</a>. Также выпускались под названиями: <strong>Colt Lancer</strong>, <strong>Dodge/Plymouth Colt</strong>, <strong>Chrysler Valiant Lancer</strong>, <strong>Chrysler Lancer</strong>, <strong>Eagle Summit</strong>, <strong>Hindustan Lancer</strong>, <strong>Soueast Lioncel</strong>, <a href="https://ru.wikipedia.org/wiki/Mitsubishi_Carisma" title="Mitsubishi Carisma">Mitsubishi Carisma</a>, <strong>Galant Fortis</strong>, и<a href="https://ru.wikipedia.org/wiki/Mitsubishi_Mirage" title="Mitsubishi Mirage">Mitsubishi Mirage</a> в разных странах и в разное время. Кроме того, продавался как <strong>Lancer Fortis</strong> на Тайване с небольшими отличиями в экстерьере по сравнению с <strong>Galant Fortis</strong>. Название Lancer переводится как улан или копьеносец.</p>', 'https://www.youtube.com/v/j0Ui9MsBZqM', 2013, 50.00, 15.00, 46, '2016-09-24 00:58:59', 1, 0, 0.00, 0, 0, 0, 1),
(36, 158, 'Jeanneau 54', 'Я́хта (нидерл. jacht, от jagen — гнать, преследовать) — первоначально лёгкое, быстрое судно для перевозки отдельных персон, оборудованное палубой и каютой (каютами). В современном понимании — любое судно, предназначенное для спортивных или туристических целей и отдыха. К яхтам не относятся рейсовые суда, предназначенные для коммерческих целей, для перевозки большого числа пассажиров (когда основная цель — транспортная, а не отдых и развлечения на борту судна) и других транспортных целей.', '<p><strong>Я́хта</strong> (<a href="https://ru.wikipedia.org/wiki/%D0%9D%D0%B8%D0%B4%D0%B5%D1%80%D0%BB%D0%B0%D0%BD%D0%B4%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA" title="Нидерландский язык">нидерл.</a> <em>jacht</em>, от jagen — гнать, преследовать) — первоначально лёгкое, быстрое <a href="https://ru.wikipedia.org/wiki/%D0%A1%D1%83%D0%B4%D0%BD%D0%BE" title="Судно">судно</a> для перевозки отдельных персон, оборудованное <a href="https://ru.wikipedia.org/wiki/%D0%9F%D0%B0%D0%BB%D1%83%D0%B1%D0%B0" title="Палуба">палубой</a> и <a href="https://ru.wikipedia.org/wiki/%D0%9A%D0%B0%D1%8E%D1%82%D0%B0" title="Каюта">каютой</a> (каютами). В современном понимании — любое судно, предназначенное для <a href="https://ru.wikipedia.org/wiki/%D0%9F%D0%B0%D1%80%D1%83%D1%81%D0%BD%D1%8B%D0%B9_%D1%81%D0%BF%D0%BE%D1%80%D1%82" title="Парусный спорт">спортивных</a> или<a href="https://ru.wikipedia.org/wiki/%D0%A2%D1%83%D1%80%D0%B8%D0%B7%D0%BC" title="Туризм">туристических</a> целей и отдыха. К яхтам не относятся <a href="https://ru.wikipedia.org/wiki/%D0%9B%D0%B0%D0%B9%D0%BD%D0%B5%D1%80_(%D1%81%D1%83%D0%B4%D0%BD%D0%BE)" title="Лайнер (судно)">рейсовые</a> суда, предназначенные для коммерческих целей, для перевозки большого числа пассажиров (когда основная цель — транспортная, а не отдых и развлечения на борту судна) и других транспортных целей.</p>', '', 2013, 200.00, 50.00, 46, '2016-09-24 01:16:51', 1, 0, 0.00, 0, 0, 0, 1),
(37, 20, 'ыфаыфам', 'фыапф', '', '', 2016, 0.00, 0.00, 50, '2016-09-29 09:44:21', 0, 0, 0.00, 0, 0, 15, 1),
(38, 21, 'ford', 'Please, describe such issues, as:\r\n•Is prepayment required?\r\n•Do you need pledge?\r\n•Are there any age restrictions?\r\n•Additional equipment, license etc\r\n', '<p>Please, describe such issues, as:</p><ul><li>Is prepayment required?</li><li>Do you need pledge?</li><li>Are there any age restrictions?</li><li>Additional equipment, license etc</li></ul>', 'https://www.youtube.com/v/vOX7dpOJZvs', 2011, 35.00, 7.00, 47, '2016-10-04 08:31:22', 0, 0, 0.00, 0, 0, 30, 0),
(39, 175, 'Bombardier Challenger 604', 'An airplane or aeroplaneA (informally plane) is a powered, fixed-wing aircraft that is propelled forward by thrust from a jet engine or propeller. Airplanes come in a variety of sizes, shapes, and wing configurations. The broad spectrum of uses for airplanes includes recreation, transportation of goods and people, military, and research. Commercial aviation is a massive industry involving the flying of tens of thousands of passengers daily on airliners. Most airplanes are flown by a pilot on board the aircraft, but some are designed to be remotely or computer-controlled.', '<p>An <strong>airplane</strong> or <strong>aeroplane</strong><sup><a href="https://en.wikipedia.org/wiki/Airplane#endnote_Alpha">A</a></sup> (informally <strong>plane</strong>) is a <a href="https://en.wikipedia.org/wiki/Motive_power" title="Motive power">powered</a>, <a href="https://en.wikipedia.org/wiki/Fixed-wing_aircraft" title="Fixed-wing aircraft">fixed-wing aircraft</a> that is propelled forward by <a href="https://en.wikipedia.org/wiki/Thrust" title="Thrust">thrust</a> from a <a href="https://en.wikipedia.org/wiki/Jet_engine" title="Jet engine">jet engine</a> or <a href="https://en.wikipedia.org/wiki/Propeller_(aircraft)" class="mw-redirect" title="Propeller (aircraft)">propeller</a>. Airplanes come in a variety of sizes, shapes, and <a href="https://en.wikipedia.org/wiki/Wing_configuration" title="Wing configuration">wing configurations</a>. The broad spectrum of uses for airplanes includes <a href="https://en.wikipedia.org/wiki/Recreation" title="Recreation">recreation</a>,<a href="https://en.wikipedia.org/wiki/Air_transportation" class="mw-redirect" title="Air transportation">transportation</a> of goods and people, <a href="https://en.wikipedia.org/wiki/Military_aviation" title="Military aviation">military</a>, and research. <a href="https://en.wikipedia.org/wiki/Commercial_aviation" title="Commercial aviation">Commercial aviation</a> is a massive industry involving the flying of tens of thousands of passengers daily on <a href="https://en.wikipedia.org/wiki/Airliners" class="mw-redirect" title="Airliners">airliners</a>. Most airplanes are flown by a <a href="https://en.wikipedia.org/wiki/Aviator" class="mw-redirect" title="Aviator">pilot</a> on board the aircraft, but some are designed to be <a href="https://en.wikipedia.org/wiki/Unmanned_aerial_vehicle" title="Unmanned aerial vehicle">remotely or computer-controlled</a>.</p>', '', 2013, 10000.00, 1500.00, 46, '2016-10-07 12:46:03', 1, 0, 0.00, 0, 0, 30, 0),
(40, 132, 'fgdfgdf', 'cvvbdfbd', '', '', NULL, 0.00, 0.00, 1, '2016-10-13 05:25:27', 0, 0, 0.00, 0, 0, 0, 0),
(41, 21, 'ford', 'Please, describe such issues, as:\r\n•Is prepayment required?\r\n•Do you need pledge?\r\n•Are there any age restrictions?\r\n•Additional equipment, license etc\r\n', '<p>במהלך אלפי שנות קיומה, הוקפה <strong><a title="חומות ירושלים" href="https://he.wikipedia.org/wiki/%D7%97%D7%95%D7%9E%D7%95%D7%AA_%D7%99%D7%A8%D7%95%D7%A9%D7%9C%D7%99%D7%9D">ירושלים בחומות</a></strong> שנועדו להגן עליה מפני אויבים. כמעט בכל פעם שהעיר נכבשה ונהרסה, חרבה גם <a title="חומה" href="https://he.wikipedia.org/wiki/%D7%97%D7%95%D7%9E%D7%94">חומתה</a>, ובדרך כלל נבנתה שוב על ידי הכובש החדש או על ידי תושבי העיר. החומה הראשונה נבנתה ב<a title="ירושלים" href="https://he.wikipedia.org/wiki/%D7%99%D7%A8%D7%95%D7%A9%D7%9C%D7%99%D7%9D">ירושלים</a> בימי ה<a title="כנענים" class="mw-redirect" href="https://he.wikipedia.org/wiki/%D7%9B%D7%A0%D7%A2%D7%A0%D7%99%D7%9D">כנענים</a> לפני למעלה מ-4,000 שנה, ו<a title="חומת ירושלים העות''מאנית" href="https://he.wikipedia.org/wiki/%D7%97%D7%95%D7%9E%D7%AA_%D7%99%D7%A8%D7%95%D7%A9%D7%9C%D7%99%D7%9D_%D7%94%D7%A2%D7%95%D7%AA%27%D7%9E%D7%90%D7%A0%D7%99%D7%AA">האחרונה</a>, הקיימת עד היום, הוקמה על ידי <a title="סולימאן הראשון" href="https://he.wikipedia.org/wiki/%D7%A1%D7%95%D7%9C%D7%99%D7%9E%D7%90%D7%9F_%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F">סולימאן הראשון</a>, <a title="סולטאן עות''מאני" href="https://he.wikipedia.org/wiki/%D7%A1%D7%95%D7%9C%D7%98%D7%90%D7%9F_%D7%A2%D7%95%D7%AA%27%D7%9E%D7%90%D7%A0%D7%99">סולטאן</a> <a title="האימפריה העות''מאנית" href="https://he.wikipedia.org/wiki/%D7%94%D7%90%D7%99%D7%9E%D7%A4%D7%A8%D7%99%D7%94_%D7%94%D7%A2%D7%95%D7%AA%27%D7%9E%D7%90%D7%A0%D7%99%D7%AA">האימפריה העות''מאנית</a> לפני כ-500 שנה.</p><p>רוב החומות שהוקמו בירושלים במהלך השנים נבנו בהתאם ל<a title="טופוגרפיה" href="https://he.wikipedia.org/wiki/%D7%98%D7%95%D7%A4%D7%95%D7%92%D7%A8%D7%A4%D7%99%D7%94">טופוגרפיה</a> הטבעית של העיר ול<a title="נקודת תורפה" href="https://he.wikipedia.org/wiki/%D7%A0%D7%A7%D7%95%D7%93%D7%AA_%D7%AA%D7%95%D7%A8%D7%A4%D7%94">נקודות התורפה</a> שלה, ולכן לרבות מהן תוואי דומה, ולעתים אף זהה. לא פעם נעשה <a title="שימוש משני" href="https://he.wikipedia.org/wiki/%D7%A9%D7%99%D7%9E%D7%95%D7%A9_%D7%9E%D7%A9%D7%A0%D7%99">שימוש משני</a> בחומה עתיקה כבסיס לבניית חומה חדשה, עד כדי יצירת <a title="קיר" href="https://he.wikipedia.org/wiki/%D7%A7%D7%99%D7%A8">קירות</a> המורכבים לעתים מכמה שכבות על פי תקופות. במחצית <a title="המאה ה-19" href="https://he.wikipedia.org/wiki/%D7%94%D7%9E%D7%90%D7%94_%D7%94-19">המאה ה-19</a>, עם תהליך <a title="היציאה מהחומות" class="mw-redirect" href="https://he.wikipedia.org/wiki/%D7%94%D7%99%D7%A6%D7%99%D7%90%D7%94_%D7%9E%D7%94%D7%97%D7%95%D7%9E%D7%95%D7%AA">היציאה מהחומות</a>, איבדה חומת ירושלים חלק ניכר מחשיבותה הביטחונית, והיא משמשת היום בעיקר כמוקד <a title="תיירות" href="https://he.wikipedia.org/wiki/%D7%AA%D7%99%D7%99%D7%A8%D7%95%D7%AA">תיירותי</a>.</p>', 'https://www.youtube.com/v/o71X3cP5p-o', 2011, 50.00, 10.00, 47, '2016-10-24 08:44:10', 1, 0, 0.00, 0, 0, 30, 0),
(42, 108, 'test', 'test', '', '', 2016, 1.00, 1.00, 60, '2016-11-01 09:42:20', 0, 0, 0.00, 0, 0, 30, 0),
(43, 24, 'My offer', 'Описание', '<p>Туча текста</p><p><br></p><p><br></p>', '', 2008, 16.00, 2.00, 60, '2016-11-03 06:58:03', 1, 0, 0.00, 0, 0, 0, 0),
(44, 4, '123123123', '123132', '<p>123123</p>', '', 2016, 1.00, 1.00, 60, '2016-11-04 08:10:04', 0, 0, 0.00, 0, 0, 15, 0),
(45, 24, 'впрт о', 'впаи твативспм', '', '', NULL, 23.00, 12.00, 46, '2016-12-14 05:35:01', 0, 0, 0.00, 0, 0, 0, 0),
(46, 24, 'впрт о', 'впаи твативспм', '', '', NULL, 23.00, 12.00, 46, '2016-12-14 05:35:38', 0, 0, 0.00, 0, 0, 0, 0),
(47, 94, '4556757', '56756778', '', '', NULL, 78.00, 78.00, 72, '2016-12-14 13:14:14', 0, 0, 0.00, 0, 0, 0, 0),
(48, 8, '657657567657', 'ВАПАВПАВП', '', '', NULL, 567.00, 567657.00, 72, '2016-12-14 14:55:35', 0, 0, 0.00, 0, 0, 0, 0),
(49, 181, 'Прыжок с парашюта', 'Прыжок с парашюта\r\nПрыжок с парашютаПрыжок с парашютаПрыжок с парашютаПрыжок с парашютаПрыжок с парашютаПрыжок с парашютаПрыжок с парашютаПрыжок с парашютаПрыжок с парашютаПрыжок с парашюта', '<p>описание по аренде по лото с какого работают условия работы</p><p>Палубное пространство по всей яхте увеличилось  от просторного \r\nсандека в 65 квадратных метров (почти 50 процентов от общей длины яхты),\r\n вплоть до размещения четырехместной лежанки для приема солнечных ванн \r\nна палубе бака.</p><p>Эта 37-метровая яхта исключительно просторна. На ней можно разместить\r\n до 5 кают, включая мастер-каюту всю ширину корпуса. 15-метровая зона \r\nдля развлечений и приемов на главной палубе простирается от кормовой \r\nчасти палубы через полукруглые, стеклянные двери во всю высоту \r\nпомещения, ведущие в салон / обеденную зону открытой планировки.</p>', '', NULL, 100.00, 100.00, 72, '2016-12-14 15:05:26', 0, 0, 0.00, 0, 0, 0, 0),
(50, 112, '657657657', '6ге6г', '<p>ге6г</p>', '', NULL, 78.00, 78.00, 72, '2016-12-14 15:37:27', 0, 0, 0.00, 0, 0, 0, 0),
(51, 175, 'Прыжок с парашюта', 'Совершите свой первый прыжок с парашютом в тандеме с инструктором с высоты 2500 — 4000 метров и со свободным падением до 1 минуты.\r\n\r\nПрыжок с парашютом в тандеме — это самый безопасный способ первый раз прыгнуть с парашютом. Прыжок выполняется в паре с опытным тандем-инструктором.', '<p>По прибытии на аэродром Вам необходимо заполнить анкету и оплатить \r\nпрыжок (если не было оплачено заранее) после  вас запишут во взлет. \r\nТакже Вы получите всё необходимое для совершения прыжка: комбинезон и \r\nперчатки (при необходимости), шлем и очки.  На Вас оденут подвесную \r\nсистему и проведут наземный инструктаж.</p><p>После\r\n этого вас знакомят с личным инструктором и воздушным оператором (если \r\nбыл заказ на фото- или видео съемку, так же это можно сделать на месте).\r\n На линии стартового осмотра экипировку еще раз проверят, и вы \r\nпроследуете в самолет. Теперь вас ждут незабываемые впечатления!</p><p>Во время прыжка, сразу после отделения от воздушного судна, \r\nпарашютист наслаждается чувством полета в свободном падении, потом \r\nинструктор раскрывает парашют. Снижение длится 5-7 минут, за это время \r\nпассажир успевает «порулить» при помощи клевант и посмотреть по \r\nсторонам. С высоты птичьего полета открывается сказочный вид на землю. \r\nПриземление мягкое и безопасное. Вы поднимаете ноги, и таким образом \r\nприземление происходит на ноги инструктора, он берет всю нагрузку на \r\nсебя.</p><p>Прыжок в тандеме можно снять на видео или фото, все ваши эмоции — </p><p>восторг, радость, ощущение полета и свободы — будут умело запечатлены </p><p>нашими воздушными операторами или самим тандем инструктором.  С </p><p>примерами видеосъёмки можно ознакомиться</p>', '', NULL, 100.00, 100.00, 72, '2016-12-15 07:11:13', 0, 0, 0.00, 0, 0, 0, 0),
(52, 94, '567657', '567567567', '<p>567567567567567</p>', '', NULL, 1.00, 1.00, 77, '2017-01-24 15:27:05', 1, 0, 0.00, 0, 0, 0, 0),
(53, 24, 'vfsdgdf', 'fsfgsfgs', '<p>rgrsgerwg</p>', '', NULL, 12.00, 12.00, 46, '2017-02-12 18:20:16', 0, 0, 0.00, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `offers_addresses`
--

CREATE TABLE IF NOT EXISTS `offers_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL,
  `is_primary` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `offer_id` (`offer_id`),
  KEY `address_id` (`address_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=182 ;

--
-- Дамп даних таблиці `offers_addresses`
--

INSERT INTO `offers_addresses` (`id`, `offer_id`, `address_id`, `is_primary`) VALUES
(155, 32, 25, 0),
(156, 33, 26, 0),
(157, 34, 27, 0),
(158, 35, 27, 0),
(159, 35, 28, 0),
(160, 36, 27, 0),
(161, 36, 28, 0),
(163, 39, 27, 0),
(164, 39, 28, 0),
(165, 40, 25, 0),
(168, 42, 31, 0),
(169, 43, 32, 0),
(174, 44, 32, 0),
(175, 44, 33, 0),
(178, 41, 29, 0),
(179, 41, 30, 0),
(181, 52, 34, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `offers_parameter_values`
--

CREATE TABLE IF NOT EXISTS `offers_parameter_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parameter_id` int(11) NOT NULL,
  `parameter_value` varchar(255) NOT NULL,
  `offer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parameter_id` (`parameter_id`),
  KEY `offer_id` (`offer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=187 ;

--
-- Дамп даних таблиці `offers_parameter_values`
--

INSERT INTO `offers_parameter_values` (`id`, `parameter_id`, `parameter_value`, `offer_id`) VALUES
(131, 7, '11', 32),
(132, 30, '1', 33),
(133, 44, '1', 34),
(134, 55, '1', 35),
(135, 65, '987', 36),
(136, 12, '7', 32),
(137, 6, '5', 32),
(138, 26, '1', 32),
(139, 33, '1', 32),
(140, 81, '1', 32),
(141, 16, '1', 32),
(143, 27, '1', 34),
(144, 5, '5000', 34),
(145, 52, '1', 34),
(146, 43, '1', 34),
(147, 35, '1', 34),
(148, 6, '5', 34),
(149, 26, '1', 34),
(150, 19, 'hh', 34),
(151, 15, '18', 34),
(152, 7, '11', 34),
(153, 33, '1', 34),
(154, 10, '1', 34),
(155, 18, '35', 34),
(156, 81, '1', 34),
(157, 16, '1', 34),
(158, 11, '14', 34),
(159, 24, '1', 34),
(160, 52, '1', 33),
(161, 22, '1', 40),
(162, 32, '1', 41),
(163, 45, '1', 41),
(164, 14, '1', 41),
(165, 22, '1', 41),
(166, 21, '1', 41),
(167, 55, '1', 41),
(168, 39, '1', 41),
(169, 30, '1', 41),
(170, 40, '1', 41),
(171, 53, '1', 41),
(172, 31, '1', 41),
(173, 23, '1', 41),
(174, 46, '1', 41),
(175, 35, '1', 41),
(176, 34, '1', 41),
(177, 43, '1', 41),
(178, 26, '1', 41),
(179, 29, '1', 41),
(180, 33, '1', 41),
(181, 28, '1', 43),
(182, 48, '1', 43),
(183, 18, '35', 43),
(184, 7, '11', 43),
(185, 11, '14', 43),
(186, 6, '9', 43);

-- --------------------------------------------------------

--
-- Структура таблиці `offer_blocks`
--

CREATE TABLE IF NOT EXISTS `offer_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `date_since` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_for` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offer_id` (`offer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=49 ;

--
-- Дамп даних таблиці `offer_blocks`
--

INSERT INTO `offer_blocks` (`id`, `offer_id`, `date_since`, `date_for`) VALUES
(36, 34, '2016-10-03 22:00:00', '2016-10-08 22:00:00'),
(37, 34, '2016-10-11 22:00:00', '2016-10-13 22:00:00'),
(38, 38, '2016-10-09 22:00:00', '2016-10-12 22:00:00'),
(39, 38, '2016-10-18 22:00:00', '2016-10-22 22:00:00'),
(41, 39, '2016-10-19 22:00:00', '2016-10-21 22:00:00'),
(42, 39, '2016-11-14 23:00:00', '2016-11-15 07:00:00'),
(43, 41, '2016-11-12 15:41:00', '2016-11-24 15:41:00'),
(44, 41, '2016-11-10 06:28:00', '2016-11-10 15:41:00'),
(45, 41, '2016-11-11 15:41:00', '2016-11-11 15:41:00'),
(46, 41, '2016-12-14 15:42:00', '2016-12-31 15:42:00'),
(47, 41, '2016-11-10 15:42:00', '2016-11-10 15:42:00'),
(48, 39, '2016-12-12 20:03:00', '2016-12-24 20:03:00');

-- --------------------------------------------------------

--
-- Структура таблиці `offer_comments`
--

CREATE TABLE IF NOT EXISTS `offer_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `text` text NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `offer_id` (`offer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп даних таблиці `offer_comments`
--

INSERT INTO `offer_comments` (`id`, `offer_id`, `author_id`, `parent_id`, `text`, `date_created`) VALUES
(1, 39, 46, NULL, 'hjjjk', '2017-01-25 18:13:41');

-- --------------------------------------------------------

--
-- Структура таблиці `offer_documents`
--

CREATE TABLE IF NOT EXISTS `offer_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `date_uploaded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `approved_by` int(11) DEFAULT NULL,
  `date_approved` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offer_id` (`offer_id`),
  KEY `approved_by` (`approved_by`),
  KEY `approved_by_2` (`approved_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

--
-- Дамп даних таблиці `offer_documents`
--

INSERT INTO `offer_documents` (`id`, `offer_id`, `title`, `filename`, `date_uploaded`, `is_approved`, `approved_by`, `date_approved`) VALUES
(25, 34, 'hhjkk', '20160923101125_eb2491cd.docx', '2016-09-23 08:11:25', 0, NULL, NULL),
(27, 35, 'hhhhh', '20160924030749_359f253e4435a.docx', '2016-09-24 01:07:49', 0, NULL, NULL),
(28, 35, 'dffggf', '20160924030804_90c1cf8827.docx', '2016-09-24 01:08:04', 0, NULL, NULL),
(29, 36, 'yyuu', '20160924032147_818bc986748f.docx', '2016-09-24 01:21:47', 0, NULL, NULL),
(30, 39, 'hhjkk', '20161007150905_0b9fd0f5dcd.docx', '2016-10-07 13:09:05', 0, NULL, NULL),
(31, 41, 'gsgs', '20161024105054_18e8fbb8a5ba.jpg', '2016-10-24 08:50:54', 0, NULL, NULL),
(32, 43, '123', '20161103080137_01bf246206.JPG', '2016-11-03 07:01:37', 0, NULL, NULL),
(33, 41, 'hbhbjn,', '20161110144321_966a95deea2d.jpg', '2016-11-10 13:43:21', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `offer_faq`
--

CREATE TABLE IF NOT EXISTS `offer_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `question` varchar(500) NOT NULL,
  `answer` text NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `offer_id` (`offer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Дамп даних таблиці `offer_faq`
--

INSERT INTO `offer_faq` (`id`, `offer_id`, `question`, `answer`, `order`) VALUES
(21, 32, 'Нужна ли страховка?', 'Нет, страхование производится по желанию и не является обязательным.', 0),
(22, 32, 'Можно ли перевозить домашних животных?', 'Да, можно.', 10),
(23, 34, ' Please, describe such issues, as:  Is prepayment required? Do you need pledge? Are there any age restrictions? Additional equipment, license etc', 'В апреле 2009 года на мотор-шоу в Нью-Йорке был представлен Range Rover Sport 2010 модельного года. В 2013 году в Нью-Йорке был представлен совершенно новый Range Rover Sport с 5-ю вариациями силовых агрегатов под капотом и "похудевший" на 420 кг за счет кузова, теперь выполненного из сплава высокопрочного алюминия. Тестировал автомобиль Дэниел Крейг.', 0),
(24, 34, 'Please, describe such issues, as:  Is prepayment required? Do you need pledge? Are there any age restrictions? Additional equipment, license etc', 'В апреле 2009 года на мотор-шоу в Нью-Йорке был представлен Range Rover Sport 2010 модельного года. В 2013 году в Нью-Йорке был представлен совершенно новый Range Rover Sport с 5-ю вариациями силовых агрегатов под капотом и "похудевший" на 420 кг за счет кузова, теперь выполненного из сплава высокопрочного алюминия. Тестировал автомобиль Дэниел Крейг.', 10),
(25, 34, 'В апреле 2009 года на мотор-шоу в Нью-Йорке был представлен Range Rover Sport 2010 модельного года.', 'В апреле 2009 года на мотор-шоу в Нью-Йорке был представлен Range Rover Sport 2010 модельного года. В 2013 году в Нью-Йорке был представлен совершенно новый Range Rover Sport с 5-ю вариациями силовых агрегатов под капотом и "похудевший" на 420 кг за счет кузова, теперь выполненного из сплава высокопрочного алюминия. Тестировал автомобиль Дэниел Крейг.', 20),
(26, 35, 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. Mitsubishi с 1973 года.  ', 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. Mitsubishi с 1973 года. Также выпускались под названиями: Colt Lancer, Dodge/Plymouth Colt, Chrysler Valiant Lancer, Chrysler Lancer, Eagle Summit, Hindustan Lancer, Soueast Lioncel, Mitsubishi Carisma, Galant Fortis, и Mitsubishi Mirage в разных странах и в разное время. Кроме того, продавался как Lancer Fortis на Тайване с небольшими отличиями в экстерьере по сравнению с Galant Fortis. Название Lancer переводится как улан или копьеносец.', 0),
(27, 35, 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. Mitsubishi с 1973 года. Также выпускались под названиями: Colt Lancer, Dodge/Plymouth Colt, Chrysler Valiant Lancer, Chrysler Lancer, Eagle Summit, Hindustan Lancer, Soueast Lioncel, Mitsubishi Carisma, Galant Fortis, и Mitsubishi Mirage в разных странах и в разное время. Кроме того, продавался как Lancer Fortis на Тайване с небольшими отличиями в экстерьере по сравнению с Galant Fortis. Название ', 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. Mitsubishi с 1973 года. Также выпускались под названиями: Colt Lancer, Dodge/Plymouth Colt, Chrysler Valiant Lancer, Chrysler Lancer, Eagle Summit, Hindustan Lancer, Soueast Lioncel, Mitsubishi Carisma, Galant Fortis, и Mitsubishi Mirage в разных странах и в разное время. Кроме того, продавался как Lancer Fortis на Тайване с небольшими отличиями в экстерьере по сравнению с Galant Fortis. Название Lancer переводится как улан или копьеносец.', 10),
(28, 35, 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемы', 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. Mitsubishi с 1973 года. Также выпускались под названиями: Colt Lancer, Dodge/Plymouth Colt, Chrysler Valiant Lancer, Chrysler Lancer, Eagle Summit, Hindustan Lancer, Soueast Lioncel, Mitsubishi Carisma, Galant Fortis, и Mitsubishi Mirage в разных странах и в разное время. Кроме того, продавался как Lancer Fortis на Тайване с небольшими отличиями в экстерьере по сравнению с Galant Fortis. Название Lancer переводится как улан или копьеносец.', 20),
(29, 39, ' Please, describe such issues, as:  Is prepayment required? Do you need pledge? Are there any age restrictions? Additional equipment, license etc', 'An airplane or aeroplaneA (informally plane) is a powered, fixed-wing aircraft that is propelled forward by thrust from a jet engine or propeller. Airplanes come in a variety of sizes, shapes, and wing configurations. The broad spectrum of uses for airplanes includes recreation, transportation of goods and people, military, and research. Commercial aviation is a massive industry involving the flying of tens of thousands of passengers daily on airliners. Most airplanes are flown by a pilot on board the aircraft, but some are designed to be remotely or computer-controlled.', 0),
(30, 41, 'adcadc', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 0),
(31, 41, 'khbhjbn', 'nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn', 10);

-- --------------------------------------------------------

--
-- Структура таблиці `offer_options`
--

CREATE TABLE IF NOT EXISTS `offer_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `price_daily` float(5,2) DEFAULT NULL,
  `price_hourly` float(5,2) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `offer_id` (`offer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=76 ;

--
-- Дамп даних таблиці `offer_options`
--

INSERT INTO `offer_options` (`id`, `offer_id`, `title`, `description`, `price_daily`, `price_hourly`, `order`, `visible`) VALUES
(41, 32, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(42, 32, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(43, 33, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(44, 33, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(45, 34, 'Аренда с водителем', 'В апреле 2009 года на мотор-шоу в Нью-Йорке был представлен Range Rover Sport 2010 модельного года. В 2013 году в Нью-Йорке был представлен совершенно новый Range Rover Sport с 5-ю вариациями силовых агрегатов под капотом и "похудевший" на 420 кг за счет кузова, теперь выполненного из сплава высокопрочного алюминия. Тестировал автомобиль Дэниел Крейг.', 100.00, 25.00, 0, 1),
(46, 34, 'Страхование покрышек и стекол', 'В апреле 2009 года на мотор-шоу в Нью-Йорке был представлен Range Rover Sport 2010 модельного года. В 2013 году в Нью-Йорке был представлен совершенно новый Range Rover Sport с 5-ю вариациями силовых агрегатов под капотом и "похудевший" на 420 кг за счет кузова, теперь выполненного из сплава высокопрочного алюминия. Тестировал автомобиль Дэниел Крейг.', 56.00, 18.00, 0, 1),
(47, 34, 'Please, describe such issues, as:  Is prepayment required? Do you need pledge? Are there any age restrictions? Additional equipment, license etc', 'В апреле 2009 года на мотор-шоу в Нью-Йорке был представлен Range Rover Sport 2010 модельного года. В 2013 году в Нью-Йорке был представлен совершенно новый Range Rover Sport с 5-ю вариациями силовых агрегатов под капотом и "похудевший" на 420 кг за счет кузова, теперь выполненного из сплава высокопрочного алюминия. Тестировал автомобиль Дэниел Крейг.', 30.00, 10.00, 10, 1),
(48, 35, 'Аренда с водителем', 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. Mitsubishi с 1973 года. Также выпускались под названиями: Colt Lancer, Dodge/Plymouth Colt, Chrysler Valiant Lancer, Chrysler Lancer, Eagle Summit, Hindustan Lancer, Soueast Lioncel, Mitsubishi Carisma, Galant Fortis, и Mitsubishi Mirage в разных странах и в разное время. Кроме того, продавался как Lancer Fortis на Тайване с небольшими отличиями в экстерьере по сравнению с Galant Fortis. Название Lancer переводится как улан или копьеносец.', 100.00, 25.00, 0, 1),
(49, 35, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(50, 35, 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. t', 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. Mitsubishi с 1973 года. Также выпускались под названиями: Colt Lancer, Dodge/Plymouth Colt, Chrysler Valiant Lancer, Chrysler Lancer, Eagle Summit, Hindustan Lancer, Soueast Lioncel, Mitsubishi Carisma, Galant Fortis, и Mitsubishi Mirage в разных странах и в разное время. Кроме того, продавался как Lancer Fortis на Тайване с небольшими отличиями в экстерьере по сравнению с Galant Fortis. Название Lancer переводится как улан или копьеносец.', 56.00, 18.00, 10, 1),
(51, 35, 'Dodge/Plymouth Colt, Chrysler Valiant Lancer, Chrysler Lancer, Eagle Summit, Hindust', 'Mitsubishi Lancer (яп. 三菱・ランサー) — семейство автомобилей, выпускаемых Mitsubishi Motors с 1973 года. Mitsubishi с 1973 года. Также выпускались под названиями: Colt Lancer, Dodge/Plymouth Colt, Chrysler Valiant Lancer, Chrysler Lancer, Eagle Summit, Hindustan Lancer, Soueast Lioncel, Mitsubishi Carisma, Galant Fortis, и Mitsubishi Mirage в разных странах и в разное время. Кроме того, продавался как Lancer Fortis на Тайване с небольшими отличиями в экстерьере по сравнению с Galant Fortis. Название Lancer переводится как улан или копьеносец.', 30.00, 10.00, 20, 1),
(52, 35, 'С момента своего введения в производство', 'Первый Lancer (A70) впервые был выпущен в феврале 1973 года. Он служил для заполнения разрыва между Minica и большим Galant. Спортивная модель GSR 1600 начала долгую и успешную историю в ралли, выиграв Ралли Сафари дважды, и Ралли Southern Cross четыре раза.', 40.00, 11.00, 30, 1),
(53, 35, 'Существовали три типа кузова', 'Существовали три типа кузова: двух-дверный седан, четырех-дверный седан и пятидверный универсал. Двигатели отличаются объемом: 1,2 литра, 1,4 литра, и 1,6 литра.\r\n\r\nЭтот автомобиль продавался под такими названиями как:\r\n\r\nDodge Colt (США, 1977—1979)\r\nDodge Lancer (В некоторых странах Латинской Америки)\r\nColt Lancer (Некоторые европейские рынки)\r\nChrysler Lancer/Valiant Lancer LA/LB (Австралия, 1974—1979)\r\nPlymouth Colt (Канада)', 10.00, 4.00, 40, 1),
(54, 35, 'В феврале 1975 Lancer был дополнен купе под названием «Mitsubishi Lancer Celeste»', 'В феврале 1975 Lancer был дополнен купе под названием «Mitsubishi Lancer Celeste», заменив Galant FTO. Также назывался «Mitsubishi Celeste» или «Colt Celeste» на некоторых рынках, а также продавался Chrysler Lancer Coupe (LB/LC) в Австралии,[2] Dodge Lancer Celeste в Сальвадоре, Plymouth Arrow в США, и Dodge Arrow в Канаде.\r\n\r\nCeleste первоначально был доступен с 1,4-и 1,6-литровыми двигателями, 2,0-литровый был добавлен позднее. Plymouth Fire Arrow с 2.6-литровым двигателем был доступен на рынке США.[3] Celeste была обновлена в 1978 году, получив угловатые фары и большие бампера.[4] Производство Lancer Celeste закончилось в июле 1981 года, так как была заменена на передне-приводную Cordia в начале 1982 года.', 30.00, NULL, 50, 1),
(55, 36, 'Я́хта (нидерл. jacht, от jagen — гнать, преследовать) — первоначально лёгкое, быстрое ', 'Я́хта (нидерл. jacht, от jagen — гнать, преследовать) — первоначально лёгкое, быстрое судно для перевозки отдельных персон, оборудованное палубой и каютой (каютами). В современном понимании — любое судно, предназначенное для спортивных или туристических целей и отдыха. К яхтам не относятся рейсовые суда, предназначенные для коммерческих целей, для перевозки большого числа пассажиров (когда основная цель — транспортная, а не отдых и развлечения на борту судна) и других транспортных целей.', 100.00, 25.00, 0, 1),
(56, 37, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(57, 37, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(58, 38, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(59, 38, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(60, 39, 'Существовали три типа кузова', 'An airplane or aeroplaneA (informally plane) is a powered, fixed-wing aircraft that is propelled forward by thrust from a jet engine or propeller. Airplanes come in a variety of sizes, shapes, and wing configurations. The broad spectrum of uses for airplanes includes recreation, transportation of goods and people, military, and research. Commercial aviation is a massive industry involving the flying of tens of thousands of passengers daily on airliners. Most airplanes are flown by a pilot on board the aircraft, but some are designed to be remotely or computer-controlled.', 300.00, 80.00, 0, 1),
(61, 41, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(62, 41, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(63, 43, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(64, 43, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(65, 44, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(66, 44, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(67, 45, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(68, 45, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(69, 46, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(70, 46, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0),
(71, 49, 'прыжок с парашута 100 метров', 'прыжок с парашута 100 метров\r\nпрыжок с парашута 100 метров\r\nпрыжок с парашута 100 метров\r\nпрыжок с парашута 100 метров', 100.00, NULL, 0, 1),
(72, 49, 'прыжок с парашута 200 метров', 'прыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метровпрыжок с парашута 200 метров', 200.00, NULL, 10, 1),
(73, 52, '456456456456456', '456546456', 1.00, 1.00, 0, 1),
(74, 53, 'Аренда с водителем', '', NULL, NULL, 0, 0),
(75, 53, 'Страхование покрышек и стекол', '', NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `offer_photos`
--

CREATE TABLE IF NOT EXISTS `offer_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `order` (`order`),
  KEY `FK_ph_id` (`offer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=134 ;

--
-- Дамп даних таблиці `offer_photos`
--

INSERT INTO `offer_photos` (`id`, `offer_id`, `filename`, `order`) VALUES
(95, 32, '20160923075748_d29ab43c.jpg', 0),
(96, 32, '20160923075752_6f4b6d7070c2d.jpg', 0),
(97, 32, '20160923075756_19c6107bd4.jpg', 0),
(98, 32, '20160923075800_d8bcd872.jpg', 0),
(99, 32, '20160923075804_360f6330a083.jpg', 0),
(100, 33, '20160923080234_be289e23988.jpg', 0),
(101, 33, '20160923080237_cc9d0e06.jpg', 50),
(102, 33, '20160923080241_2c54f476e4d11.jpg', 10),
(103, 33, '20160923080248_d29703a71.jpg', 40),
(104, 33, '20160923080253_3617789079.jpg', 20),
(105, 33, '20160923080259_c8d35ff47f70d.jpg', 30),
(106, 34, '20160923100807_7bdfaf89c71af.jpg', 0),
(107, 34, '20160923100824_9aeb814607.jpg', 10),
(108, 34, '20160923100829_24798432c6402.jpg', 20),
(109, 35, '20160924030225_3923c0e4f951.jpg', 0),
(110, 35, '20160924030231_e833448.jpg', 0),
(111, 35, '20160924030236_5db75c89d2d6.jpg', 0),
(112, 35, '20160924030242_4f5c7bbe2de.jpg', 0),
(113, 36, '20160924032035_ed8e30572e.jpg', 10),
(114, 36, '20160924032039_215f80ba.jpg', 0),
(115, 36, '20160924032043_3f2fde3.jpg', 20),
(116, 36, '20160924032048_29875e20013b5.jpg', 30),
(117, 39, '20161007150729_8c6ad9ca28fd.jpg', 0),
(118, 39, '20161007150743_274fddd0a2b98.jpg', 0),
(119, 33, '20161009072403_4b157db1a.jpg', 0),
(120, 43, '20161103080046_ff73673a443c.jpg', 0),
(121, 43, '20161104093751_7407bec.JPG', 0),
(122, 41, '20161110143848_3c57ff7.jpg', 0),
(123, 41, '20161110143858_9c5223103.jpg', 0),
(124, 41, '20161110143909_5255edd17.jpg', 0),
(126, 41, '20161110143928_6337976b66a55.jpg', 0),
(127, 41, '20161110143935_a3b1a7de.jpg', 0),
(128, 41, '20161110143942_2c2ba5e.jpg', 0),
(129, 41, '20161110143951_6e231543.jpg', 0),
(130, 41, '20161110144002_954dd80.jpg', 0),
(131, 49, '20161214160636_cb83c23280.jpg', 0),
(132, 51, '20161215081142_0859b208f7.jpg', 0),
(133, 52, '20170124162752_7d3a5f1c955.jpg', 0);

-- --------------------------------------------------------

--
-- Структура таблиці `offer_reviews`
--

CREATE TABLE IF NOT EXISTS `offer_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `response` text,
  `rating` int(11) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `offer_id` (`offer_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблиці `offer_review_photos`
--

CREATE TABLE IF NOT EXISTS `offer_review_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `review_id` (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблиці `ordered_options`
--

CREATE TABLE IF NOT EXISTS `ordered_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `option_id` (`option_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=95 ;

--
-- Дамп даних таблиці `ordered_options`
--

INSERT INTO `ordered_options` (`id`, `order_id`, `option_id`) VALUES
(58, 56, 45),
(59, 56, 46),
(87, 63, 46),
(88, 64, 41),
(90, 70, 60),
(91, 71, 55),
(92, 72, 73),
(94, 73, 73);

-- --------------------------------------------------------

--
-- Структура таблиці `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date_since` datetime NOT NULL,
  `date_for` datetime NOT NULL,
  `time_to_prepare` int(5) NOT NULL DEFAULT '0',
  `date_for_real` timestamp NULL DEFAULT NULL,
  `address_from` int(11) DEFAULT NULL,
  `address_to` int(11) DEFAULT NULL,
  `price_type` int(1) NOT NULL DEFAULT '0',
  `price_daily` float(10,2) DEFAULT NULL,
  `price_hourly` float(10,2) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_changed` timestamp NULL DEFAULT NULL,
  `discount` float(5,2) NOT NULL DEFAULT '0.00',
  `total_cost` float(10,2) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `canceled_by` int(11) DEFAULT NULL,
  `canceled_date` timestamp NULL DEFAULT NULL,
  `cancel_approved` int(1) DEFAULT '0',
  `log` text,
  `notes` text,
  `release_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offer_id` (`offer_id`),
  KEY `client_id` (`client_id`),
  KEY `offer_id_2` (`offer_id`),
  KEY `client_id_2` (`client_id`),
  KEY `address_from` (`address_from`),
  KEY `address_to` (`address_to`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=75 ;

--
-- Дамп даних таблиці `orders`
--

INSERT INTO `orders` (`id`, `offer_id`, `client_id`, `date_since`, `date_for`, `time_to_prepare`, `date_for_real`, `address_from`, `address_to`, `price_type`, `price_daily`, `price_hourly`, `date_created`, `date_changed`, `discount`, `total_cost`, `status`, `canceled_by`, `canceled_date`, `cancel_approved`, `log`, `notes`, `release_code`) VALUES
(56, 34, 46, '2016-09-26 00:00:00', '2016-10-02 00:00:00', 0, '2016-10-01 22:00:00', 157, 157, 1, 200.00, 50.00, '2016-09-26 00:43:06', '2016-09-26 00:43:24', 0.00, 2136.00, -10, NULL, NULL, 0, NULL, 'ггпр', NULL),
(63, 34, 1, '2016-10-20 00:00:00', '2016-11-23 00:00:00', 0, '2016-11-22 23:00:00', 157, 157, 1, 200.00, 50.00, '2016-10-03 17:56:56', '2016-10-19 22:00:01', 0.00, 8704.00, -10, NULL, NULL, 0, NULL, '', NULL),
(64, 32, 46, '2016-11-07 00:00:00', '2016-11-11 00:00:00', 0, '2016-11-10 23:00:00', 155, 155, 1, 100.00, 10.00, '2016-10-05 00:51:30', '2016-10-06 00:55:01', 0.00, 400.00, -10, NULL, NULL, 0, NULL, 'kkkkk', NULL),
(66, 43, 60, '2016-11-03 10:11:00', '2016-11-20 10:11:00', 0, '2016-11-20 09:11:00', 169, 169, 1, 16.00, 2.00, '2016-11-03 07:12:01', '2016-11-03 09:15:01', 0.00, 272.00, -10, NULL, NULL, 0, NULL, '', NULL),
(67, 43, 63, '2016-11-05 11:31:00', '2016-12-02 11:31:00', 0, '2016-12-02 10:31:00', 169, 169, 1, 16.00, 2.00, '2016-11-04 08:32:02', '2016-11-04 08:35:44', 0.00, 432.00, 30, NULL, NULL, 0, NULL, '', '576B787DCD'),
(68, 41, 47, '2016-11-14 16:46:00', '2016-11-20 16:46:00', 30, '2016-11-20 16:16:00', 178, 178, 1, 50.00, 10.00, '2016-11-10 13:46:38', '2016-11-11 13:50:01', 0.00, 300.00, -10, NULL, NULL, 0, NULL, '', NULL),
(69, 39, 46, '2016-12-12 21:05:00', '2016-12-16 21:05:00', 30, '2016-12-16 20:35:00', 163, 163, 1, 10000.00, 1500.00, '2016-11-10 18:06:23', '2016-11-11 18:10:01', 0.00, 40000.00, -10, NULL, NULL, 0, NULL, '', NULL),
(70, 39, 46, '2016-12-17 12:55:00', '2016-12-24 12:55:00', 30, '2016-12-24 12:25:00', 163, 163, 1, 10000.00, 1500.00, '2016-12-14 09:55:19', '2016-12-17 11:55:01', 0.00, 72100.00, -10, NULL, NULL, 0, NULL, '', NULL),
(71, 36, 72, '2017-01-11 17:17:00', '2017-01-21 11:17:00', 0, '2017-01-21 10:17:00', 160, 160, 1, 200.00, 50.00, '2017-01-10 07:18:50', '2017-01-11 07:20:02', 0.00, 3000.00, -10, NULL, NULL, 0, NULL, 'gujkgkg', NULL),
(72, 52, 77, '2017-01-24 19:31:00', '2017-01-25 19:31:00', 0, '2017-01-25 18:31:00', 181, 181, 1, 1.00, 1.00, '2017-01-24 15:32:14', '2017-01-24 18:35:01', 0.00, 2.00, -10, NULL, NULL, 0, NULL, 'прорпо', NULL),
(73, 52, 77, '2017-01-26 19:37:00', '2017-01-29 19:37:00', 0, '2017-01-29 18:37:00', 181, 181, 1, 1.00, 1.00, '2017-01-24 15:39:07', '2017-01-25 15:45:01', 0.00, 6.00, -10, NULL, NULL, 0, NULL, '', NULL),
(74, 36, 47, '2017-02-07 10:50:00', '2017-02-08 10:50:00', 0, '2017-02-08 09:50:00', 160, 160, 1, 200.00, 50.00, '2017-01-28 07:50:58', '2017-01-29 07:55:01', 0.00, 200.00, -10, NULL, NULL, 0, NULL, '', NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `parameters`
--

CREATE TABLE IF NOT EXISTS `parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `is_required` int(1) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=124 ;

--
-- Дамп даних таблиці `parameters`
--

INSERT INTO `parameters` (`id`, `group_id`, `name`, `type`, `is_required`, `order`) VALUES
(5, 1, 'Объём двигателя', 1, 1, 0),
(6, 1, 'Вид топлива', 0, 1, 0),
(7, 1, 'Коробка передач', 0, 1, 0),
(8, 1, 'Пробег', 1, 1, 0),
(9, 1, 'Цвет ', 2, 1, 0),
(10, 1, '4х4', 3, 1, 0),
(11, 1, 'Привод ', 0, 1, 0),
(12, 1, 'Количество мест ', 1, 1, 0),
(13, 2, 'Кондиционер', 0, 1, 0),
(14, 2, 'Парктроник', 3, 1, 0),
(15, 2, 'Видеорегистратор', 4, 1, 0),
(16, 1, 'Фаркоп', 3, 1, 0),
(17, 1, 'Розетка 12v, шт', 1, 1, 0),
(18, 1, 'Сторона руля', 0, 1, 0),
(19, 1, 'Количество дверей ', 1, 1, 0),
(20, 1, 'Расход топлива (смешанный цикл)', 1, 1, 0),
(21, 2, 'ABD', 3, 1, 0),
(22, 2, 'ABS', 3, 1, 0),
(23, 2, 'ESP', 3, 1, 0),
(24, 1, 'Бронированный автомобиль', 3, 1, 0),
(25, 1, 'Замок на КПП', 3, 1, 0),
(26, 1, 'Иммобилайзер', 3, 1, 0),
(27, 1, 'Пневмоподвеска', 3, 1, 0),
(28, 2, 'Подушки безопасности (Airbag), шт', 1, 1, 0),
(29, 1, 'Серворуль', 3, 1, 0),
(30, 2, 'Сигнализация', 3, 1, 0),
(31, 2, 'Центральный замок', 3, 1, 0),
(32, 2, 'Бортовой компьютер', 3, 1, 0),
(33, 1, 'Датчик света', 3, 1, 0),
(34, 1, 'Климат контроль', 3, 1, 0),
(35, 1, 'Кожаный салон', 3, 1, 0),
(37, 2, 'Круиз контроль', 3, 1, 0),
(38, 2, 'Люк', 3, 1, 0),
(39, 2, 'Мультируль', 3, 1, 0),
(40, 2, 'Омыватель фар', 3, 1, 0),
(41, 1, 'Парктроник', 3, 1, 0),
(42, 1, 'Подогрев зеркал', 3, 1, 0),
(43, 1, 'Подогрев сидений', 3, 1, 0),
(44, 1, 'Сенсор дождя', 3, 1, 0),
(45, 2, 'Усилитель руля', 3, 1, 0),
(46, 2, 'Эл. стеклоподъемники', 3, 1, 0),
(47, 2, 'Электропакет', 3, 1, 0),
(48, 2, 'Тонирование стекол', 2, 1, 0),
(49, 1, 'Тюнинг', 2, 1, 0),
(52, 1, 'MP3', 3, 1, 0),
(53, 2, 'AUX', 3, 1, 0),
(54, 2, 'USB', 3, 1, 0),
(55, 2, 'SD', 3, 1, 0),
(56, 1, 'Пассажировместимость', 1, 1, 0),
(57, 1, 'Количество спальных мест ', 1, 1, 0),
(58, 1, 'Количество кают ', 4, 1, 0),
(59, 1, 'Год постройки ', 1, 1, 0),
(60, 1, 'Год обновления ', 1, 1, 0),
(61, 1, 'Экипаж', 2, 1, 0),
(62, 1, 'Санитарный узел/ гальюн ', 3, 1, 0),
(63, 1, 'Габаритная длина', 1, 1, 0),
(64, 1, 'Ширина (Бимс) ', 1, 1, 0),
(65, 1, 'Осадка', 1, 1, 0),
(66, 1, 'Объем бака для воды ', 1, 1, 0),
(67, 1, 'Объем топливного бака ', 1, 1, 0),
(68, 1, 'Мощность', 0, 1, 0),
(69, 1, 'Тип двигателя ', 0, 1, 0),
(70, 1, 'Максимальная круизная скорость ', 1, 1, 0),
(71, 1, 'Расход топлива ', 1, 1, 0),
(72, 1, 'Грот', 2, 1, 0),
(73, 1, 'Генуя', 2, 1, 0),
(74, 1, 'Спинакер', 2, 1, 0),
(75, 1, 'Генакер ', 2, 1, 0),
(76, 1, 'Ловушка грота (Lazy-jack) ', 2, 1, 0),
(77, 2, 'GPS ', 3, 1, 0),
(78, 2, 'Автопилот', 3, 1, 0),
(79, 1, 'Анемометр', 3, 1, 0),
(80, 1, 'Радио VHF ', 3, 1, 0),
(81, 1, 'Спидометр', 3, 1, 0),
(82, 1, 'Эхолот', 3, 1, 0),
(83, 1, 'Кардридер', 3, 1, 0),
(84, 1, 'Преобразователь 220V ', 3, 1, 0),
(85, 1, 'Горячая вода ', 3, 1, 0),
(86, 1, 'Вентилятор', 3, 1, 0),
(87, 1, 'Генератор', 3, 1, 0),
(88, 2, 'Кондиционер', 3, 1, 0),
(89, 1, 'Опреснитель морской воды ', 3, 1, 0),
(90, 1, 'Солнечная батарея ', 3, 1, 0),
(91, 1, 'Отопитель', 3, 1, 0),
(92, 1, 'Ванна', 3, 1, 0),
(93, 1, 'Джакузи', 3, 1, 0),
(94, 1, 'Стиральная машина ', 3, 1, 0),
(95, 1, 'Защитная экипировка ', 2, 1, 0),
(96, 1, 'Путеводитель и карты ', 2, 1, 0),
(97, 1, 'Бимини', 3, 1, 0),
(98, 1, 'Колонки в кокпите ', 3, 1, 0),
(99, 1, 'Лестница для купания ', 2, 1, 0),
(100, 1, 'Палубный душ ', 3, 1, 0),
(101, 1, 'Тент', 2, 1, 0),
(102, 1, 'Электрический брашпиль ', 3, 1, 0),
(103, 1, 'Стол в кокпите ', 2, 1, 0),
(104, 1, 'Брызгозащитный козырёк', 3, 1, 0),
(105, 1, 'Носовое подруливающее устройство', 3, 1, 0),
(106, 1, 'Палуба из тика ', 2, 1, 0),
(107, 1, 'Электрическая лебёдка ', 3, 1, 0),
(108, 1, 'Плита', 3, 1, 0),
(109, 1, 'Электрический холодильник ', 3, 1, 0),
(110, 1, 'Морозилка', 3, 1, 0),
(111, 1, 'Микроволновая печь ', 3, 1, 0),
(112, 1, 'Кофеварка', 3, 1, 0),
(113, 1, 'Льдогенератор', 3, 1, 0),
(114, 1, 'Тостер', 3, 1, 0),
(115, 1, 'Посуда', 2, 1, 0),
(116, 1, 'CD-плеер', 3, 1, 0),
(117, 2, 'DVD-плеер', 3, 1, 0),
(118, 1, 'Барбекю', 2, 1, 0),
(119, 1, 'Маски и трубки', 2, 1, 0),
(120, 1, 'Настольные игры', 2, 1, 0),
(121, 1, 'Подключение MP3 - Ipod', 3, 1, 0),
(122, 1, 'Подключение к Интернету (Wi–Fi)', 3, 1, 0),
(123, 1, 'Телевизор', 3, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `parameters_categories`
--

CREATE TABLE IF NOT EXISTS `parameters_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parameter_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parameter_id` (`parameter_id`),
  KEY `category_id` (`category_id`),
  KEY `parameter_id_2` (`parameter_id`),
  KEY `category_id_2` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=291 ;

--
-- Дамп даних таблиці `parameters_categories`
--

INSERT INTO `parameters_categories` (`id`, `parameter_id`, `category_id`) VALUES
(13, 65, 2),
(14, 83, 2),
(15, 86, 2),
(16, 89, 2),
(17, 92, 2),
(18, 78, 2),
(19, 68, 2),
(20, 71, 2),
(21, 74, 2),
(22, 77, 2),
(23, 95, 2),
(24, 113, 2),
(25, 119, 2),
(26, 122, 2),
(27, 108, 2),
(28, 98, 2),
(29, 101, 2),
(30, 104, 2),
(31, 107, 2),
(32, 72, 2),
(33, 75, 2),
(34, 93, 2),
(35, 114, 2),
(36, 63, 2),
(37, 82, 2),
(38, 85, 2),
(39, 13, 2),
(40, 91, 2),
(41, 79, 2),
(42, 67, 2),
(43, 70, 2),
(44, 73, 2),
(45, 76, 2),
(46, 94, 2),
(47, 112, 2),
(48, 115, 2),
(49, 118, 2),
(50, 121, 2),
(51, 109, 2),
(52, 97, 2),
(53, 100, 2),
(54, 103, 2),
(55, 106, 2),
(56, 64, 2),
(57, 58, 2),
(58, 61, 2),
(59, 37, 2),
(60, 65, 2),
(61, 83, 2),
(62, 86, 2),
(63, 89, 2),
(64, 92, 2),
(65, 78, 2),
(66, 68, 2),
(67, 71, 2),
(68, 74, 2),
(69, 77, 2),
(70, 95, 2),
(71, 113, 2),
(72, 116, 2),
(73, 119, 2),
(74, 122, 2),
(75, 108, 2),
(76, 98, 2),
(77, 101, 2),
(78, 104, 2),
(79, 107, 2),
(80, 56, 2),
(81, 59, 2),
(82, 62, 2),
(83, 84, 2),
(84, 87, 2),
(85, 90, 2),
(86, 80, 2),
(87, 66, 2),
(88, 69, 2),
(89, 72, 2),
(90, 75, 2),
(91, 93, 2),
(92, 111, 2),
(93, 114, 2),
(94, 117, 2),
(95, 120, 2),
(96, 110, 2),
(97, 96, 2),
(98, 99, 2),
(99, 102, 2),
(100, 105, 2),
(101, 123, 2),
(102, 20, 2),
(103, 63, 2),
(104, 82, 2),
(105, 85, 2),
(106, 13, 2),
(107, 91, 2),
(108, 79, 2),
(109, 67, 2),
(110, 70, 2),
(111, 73, 2),
(112, 76, 2),
(113, 94, 2),
(114, 112, 2),
(115, 115, 2),
(116, 118, 2),
(117, 121, 2),
(118, 109, 2),
(119, 97, 2),
(120, 100, 2),
(121, 103, 2),
(122, 106, 2),
(123, 64, 2),
(124, 58, 2),
(125, 61, 2),
(126, 37, 2),
(127, 5, 1),
(128, 23, 1),
(129, 26, 1),
(130, 29, 1),
(131, 32, 1),
(132, 18, 1),
(133, 8, 1),
(134, 11, 1),
(135, 14, 1),
(136, 17, 1),
(137, 35, 1),
(138, 53, 1),
(139, 48, 1),
(140, 38, 1),
(142, 44, 1),
(143, 47, 1),
(144, 81, 1),
(145, 21, 1),
(146, 24, 1),
(147, 27, 1),
(148, 30, 1),
(149, 6, 1),
(150, 9, 1),
(151, 12, 1),
(152, 15, 1),
(153, 33, 1),
(154, 117, 1),
(156, 39, 1),
(157, 42, 1),
(158, 45, 1),
(159, 22, 1),
(160, 25, 1),
(161, 28, 1),
(162, 31, 1),
(163, 19, 1),
(164, 7, 1),
(165, 10, 1),
(166, 13, 1),
(167, 16, 1),
(168, 34, 1),
(169, 52, 1),
(170, 55, 1),
(171, 49, 1),
(172, 40, 1),
(173, 43, 1),
(174, 46, 1),
(175, 5, 1),
(176, 23, 1),
(177, 26, 1),
(178, 29, 1),
(179, 32, 1),
(180, 18, 1),
(181, 8, 1),
(182, 11, 1),
(184, 17, 1),
(185, 35, 1),
(186, 53, 1),
(187, 48, 1),
(188, 38, 1),
(190, 44, 1),
(191, 47, 1),
(192, 81, 1),
(193, 21, 1),
(194, 24, 1),
(195, 27, 1),
(196, 30, 1),
(197, 6, 1),
(198, 9, 1),
(199, 12, 1),
(200, 15, 1),
(201, 33, 1),
(202, 117, 1),
(203, 116, 1),
(205, 39, 1),
(206, 42, 1),
(207, 45, 1),
(208, 22, 1),
(209, 25, 1),
(210, 28, 1),
(211, 31, 1),
(212, 19, 1),
(213, 7, 1),
(214, 10, 1),
(215, 13, 1),
(216, 16, 1),
(217, 34, 1),
(218, 52, 1),
(219, 55, 1),
(220, 49, 1),
(221, 40, 1),
(222, 43, 1),
(223, 46, 1),
(224, 65, 2),
(225, 83, 2),
(226, 86, 2),
(227, 89, 2),
(228, 92, 2),
(229, 78, 2),
(230, 68, 2),
(231, 71, 2),
(232, 74, 2),
(233, 77, 2),
(234, 95, 2),
(235, 113, 2),
(236, 116, 2),
(237, 119, 2),
(238, 122, 2),
(239, 108, 2),
(240, 98, 2),
(241, 101, 2),
(242, 104, 2),
(243, 107, 2),
(244, 56, 2),
(245, 59, 2),
(246, 62, 2),
(247, 84, 2),
(248, 87, 2),
(249, 90, 2),
(250, 80, 2),
(251, 66, 2),
(252, 69, 2),
(253, 72, 2),
(254, 75, 2),
(255, 93, 2),
(256, 111, 2),
(257, 114, 2),
(258, 117, 2),
(259, 120, 2),
(260, 110, 2),
(261, 96, 2),
(262, 99, 2),
(263, 102, 2),
(264, 105, 2),
(265, 123, 2),
(266, 20, 2),
(267, 63, 2),
(268, 82, 2),
(269, 85, 2),
(270, 13, 2),
(271, 91, 2),
(272, 79, 2),
(273, 67, 2),
(274, 70, 2),
(275, 73, 2),
(276, 76, 2),
(277, 94, 2),
(278, 112, 2),
(279, 115, 2),
(280, 118, 2),
(281, 121, 2),
(282, 109, 2),
(283, 97, 2),
(284, 100, 2),
(285, 103, 2),
(286, 106, 2),
(287, 64, 2),
(288, 58, 2),
(289, 61, 2),
(290, 37, 2);

-- --------------------------------------------------------

--
-- Структура таблиці `parameter_groups`
--

CREATE TABLE IF NOT EXISTS `parameter_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп даних таблиці `parameter_groups`
--

INSERT INTO `parameter_groups` (`id`, `name`, `order`) VALUES
(1, 'Основные параметры', 0),
(2, 'Доп. оборудование', 10);

-- --------------------------------------------------------

--
-- Структура таблиці `parameter_values`
--

CREATE TABLE IF NOT EXISTS `parameter_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parameter_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parameter_id` (`parameter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Дамп даних таблиці `parameter_values`
--

INSERT INTO `parameter_values` (`id`, `parameter_id`, `value`) VALUES
(5, 6, 'Бензин'),
(6, 6, 'Дизель'),
(7, 6, 'Газ'),
(8, 6, 'Электра'),
(9, 6, 'Гибрид'),
(10, 6, 'Другое'),
(11, 7, 'Автомат'),
(12, 7, 'Типтроник'),
(13, 7, 'Механика'),
(14, 11, 'Передний'),
(15, 11, 'Задний'),
(16, 13, 'Холод'),
(17, 13, 'Тепло'),
(18, 15, 'Передний'),
(19, 15, 'Задний'),
(20, 20, 'Город'),
(21, 20, 'Шоссе'),
(22, 20, 'Смешанный'),
(23, 58, 'Одноместные'),
(24, 58, 'Двухместные'),
(25, 58, 'Трёхместные'),
(26, 58, 'Каюта для экипажа  '),
(29, 68, '1 = л.с'),
(30, 68, '2 = л.с'),
(31, 69, 'Дизель'),
(32, 69, 'Бензин'),
(33, 69, 'Другое'),
(34, 11, 'Полный'),
(35, 18, 'Слева'),
(36, 18, 'Справа');

-- --------------------------------------------------------

--
-- Структура таблиці `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `payment_type` int(3) NOT NULL,
  `type` int(11) NOT NULL,
  `amount` float(10,2) NOT NULL,
  `payer_name` varchar(255) DEFAULT NULL,
  `country` varchar(255) NOT NULL DEFAULT 'USA',
  `transfer_number` varchar(255) DEFAULT NULL,
  `log` text,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `approved_by` int(11) DEFAULT NULL,
  `date_approved` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `order_id` (`order_id`),
  KEY `payment_type` (`payment_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=52 ;

--
-- Дамп даних таблиці `payments`
--

INSERT INTO `payments` (`id`, `order_id`, `client_id`, `payment_type`, `type`, `amount`, `payer_name`, `country`, `transfer_number`, `log`, `date_created`, `is_approved`, `approved_by`, `date_approved`) VALUES
(48, NULL, 60, 1, 2, 1.00, NULL, 'USA', NULL, NULL, '2016-11-01 08:07:27', 0, NULL, NULL),
(49, 67, 63, 1, 0, 432.00, NULL, 'USA', NULL, NULL, '2016-11-04 08:35:43', 0, NULL, NULL),
(50, 67, 63, 1, 2, 432.00, 'AutoPayment', 'USA', NULL, NULL, '2016-11-04 08:35:44', 1, 1, '2016-11-04 08:35:44'),
(51, NULL, 72, 1, 2, 100.00, NULL, 'USA', NULL, NULL, '2016-12-12 18:19:45', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `payment_types`
--

CREATE TABLE IF NOT EXISTS `payment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп даних таблиці `payment_types`
--

INSERT INTO `payment_types` (`id`, `name`, `description`, `order`) VALUES
(1, 'Credit Cards', '', 0),
(2, 'PayPal', '', 10);

-- --------------------------------------------------------

--
-- Структура таблиці `places`
--

CREATE TABLE IF NOT EXISTS `places` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `name` varchar(500) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `province_id` (`province_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп даних таблиці `places`
--

INSERT INTO `places` (`id`, `type`, `name`, `province_id`, `address`) VALUES
(1, 0, 'Аэропорт им. Джона Кеннеди', 2, '');

-- --------------------------------------------------------

--
-- Структура таблиці `popups`
--

CREATE TABLE IF NOT EXISTS `popups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `html` text,
  `delay` int(11) NOT NULL DEFAULT '10',
  `period` int(11) NOT NULL DEFAULT '60',
  `date_expires` timestamp NULL DEFAULT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблиці `preoptions`
--

CREATE TABLE IF NOT EXISTS `preoptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп даних таблиці `preoptions`
--

INSERT INTO `preoptions` (`id`, `category_id`, `title`, `description`) VALUES
(1, 5, 'Аренда с водителем', ''),
(2, 5, 'Страхование покрышек и стекол', '');

-- --------------------------------------------------------

--
-- Структура таблиці `private_messages`
--

CREATE TABLE IF NOT EXISTS `private_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recepient_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_seen` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `recepient_id` (`recepient_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп даних таблиці `private_messages`
--

INSERT INTO `private_messages` (`id`, `recepient_id`, `sender_id`, `text`, `date_created`, `is_seen`, `status`) VALUES
(1, 1, 46, 'привет', '2016-09-26 00:48:41', 1, 0),
(2, 1, 46, 'ооооо', '2016-09-26 00:48:48', 1, 0),
(3, 1, 46, 'длодд', '2016-09-26 00:48:54', 1, 0),
(5, 55, 55, '55', '2016-10-13 07:56:44', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
  `user_id` int(11) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT '',
  `lastname` varchar(50) DEFAULT NULL,
  `notes` text,
  `public_phone` varchar(50) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `city` varchar(255) NOT NULL DEFAULT '',
  `alter_phone` varchar(20) NOT NULL DEFAULT '',
  `gender` int(1) DEFAULT NULL,
  `birthday` date DEFAULT '1970-01-01',
  `is_company` int(1) NOT NULL DEFAULT '0',
  `languages` varchar(500) NOT NULL DEFAULT '',
  `photo2` varchar(255) DEFAULT NULL,
  `photo3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `profiles`
--

INSERT INTO `profiles` (`user_id`, `photo`, `firstname`, `lastname`, `notes`, `public_phone`, `country_id`, `city`, `alter_phone`, `gender`, `birthday`, `is_company`, `languages`, `photo2`, `photo3`) VALUES
(1, '20160522181042_5b1f48c833.jpg', 'ADM', 'ADM', '', '', 232, 'Kharkiv', '', 0, '1990-03-06', 1, 'English, Русский, Украинский', '20160823131236_34c301f3.jpg', '20160823131240_e7bfd574c545a.jpg'),
(46, '20160923084942_917dfcdc1.jpg', 'Alexandr', 'Merkushyn', 'hgghgggffuu', '533334709', 105, 'jerusalem', '33333444', 0, '1986-08-11', 1, '8,13,45', '20160923085519_65c3dd270.jpg', '20160923085519_8782f81478a.jpg'),
(50, NULL, 'Alexandr', '', '', '', 105, '', '', NULL, '1970-01-01', 0, '', NULL, NULL),
(51, '20161001121531_39eb0e0.jpg', 'Dimitry', 'Naumchik', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(52, '20161006070631_f266d3a316.jpg', 'Andrey', 'Alekseevich', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(53, '20161012144755_1f0f42920966.jpg', 'Андрей', 'Мельник', '', NULL, NULL, '', '', 0, '2016-10-12', 0, '', NULL, NULL),
(54, '20161013054943_8d35afb8a6e.jpg', 'Vitaliy', 'Demianenko', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(55, '20161013094050_46dd18c4c61.jpg', 'Vitalii', 'Brodovenko', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(57, '20161019131653_857c80da1c8.jpg', 'Nicolas', 'Kharchenko', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(59, '20161024063532_fc633ba2f4c7.jpg', 'Yuriy', 'Cheremischuk', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(60, '20161101090149_5ddb74e10f4.jpg', 'Денис', 'Латтов', '', '45654654654654', 232, 'Одесса', '', 0, '2016-11-01', 0, '8,23', NULL, NULL),
(61, '20161101094053_ccfd545c.jpg', 'Славик', 'Димитрищук', '', NULL, NULL, '', '', 0, '2016-11-01', 0, '', NULL, NULL),
(63, '20161104084532_ec080722.jpg', 'Vorodin', 'Sergey', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(72, NULL, '', 'тест', '', '', NULL, '', '', NULL, '1970-01-01', 0, '', NULL, NULL),
(73, '20161206090032_0b4c6fa15cf.jpg', 'Станислав', 'Гриньков', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(74, '20161207162629_0237292.jpg', 'Vyacheslav', 'Prokosa', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(81, '20170128111130_e69f40818d2.jpg', 'Игорь', 'Игорь', '', '546756765765765', NULL, 'Киев', '5676576576575675', 1, '2017-01-28', 1, '', NULL, NULL),
(83, '20170128112901_34499c3f.jpg', 'getupway', 'Merkushyn', '', NULL, NULL, '', '', 1, '2017-01-28', 0, '', NULL, NULL),
(84, '20170212170249_98fe705e4e.jpg', 'Roman', 'Filipovsky', NULL, NULL, NULL, '', '', 0, NULL, 0, '', NULL, NULL),
(85, '20170219191453_f362ff7d0c79c.jpg', 'o5l', 'o5l', '', NULL, NULL, '', '', 1, '2017-02-19', 0, '', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `profiles_fields`
--

CREATE TABLE IF NOT EXISTS `profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Дамп даних таблиці `profiles_fields`
--

INSERT INTO `profiles_fields` (`id`, `varname`, `title`, `field_type`, `field_size`, `field_size_min`, `required`, `match`, `range`, `error_message`, `other_validator`, `default`, `widget`, `widgetparams`, `position`, `visible`) VALUES
(1, 'photo', 'Фотография', 'VARCHAR', 255, 0, 0, '', '', '', '', '', '', '', 20, 3),
(2, 'firstname', 'Имя', 'VARCHAR', 50, 3, 2, '', '', 'Incorrect First Name (length between 3 and 50 characters).', '', '', '', '', 10, 3),
(3, 'lastname', 'Фамилия', 'VARCHAR', 50, 3, 2, '', '', 'Incorrect Last Name (length between 3 and 50 characters).', '', '', '', '', 0, 3),
(5, 'public_phone', 'Общедоступный телефон', 'VARCHAR', 50, 0, 0, '', '', '', '', '', '', '', 40, 3),
(6, 'country_id', 'Страна', 'INT', 11, 0, 0, '', '', '', '', '', '', '', 50, 3),
(10, 'notes', 'О себе', 'TEXT', 65000, 0, 0, '', '', '', '', '', '', '', 30, 3),
(11, 'city', 'Город', 'VARCHAR', 255, 0, 0, '', '', '', '', '', '', '', 60, 3),
(12, 'alter_phone', 'Запасной номер телефона', 'VARCHAR', 20, 0, 0, '', '', '', '', '', '', '', 70, 3),
(13, 'gender', 'Пол', 'INTEGER', 1, 0, 0, '', '0==Мужской;1==Женский', '', '', '0', '', '', 80, 3),
(14, 'birthday', 'Дата рождения', 'DATE', 0, 0, 0, '', '', '', '', '1970-01-01', 'UWjuidate', '', 90, 3),
(15, 'is_company', 'Являюсь юридическим лицом', 'INTEGER', 1, 0, 0, '', '', '', '', '0', 'UWcheckBox', '', 100, 3),
(16, 'languages', 'Владею языками', 'VARCHAR', 500, 0, 0, '', '', '', '', '', '', '', 110, 3),
(17, 'photo2', 'Доп. фотография', 'VARCHAR', 255, 0, 0, '', '', '', '', '', '', '', 23, 3),
(18, 'photo3', 'Доп. фотография', 'VARCHAR', 255, 0, 0, '', '', '', '', '', '', '', 27, 3);

-- --------------------------------------------------------

--
-- Структура таблиці `site_vars`
--

CREATE TABLE IF NOT EXISTS `site_vars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `wysiwyg_on` tinyint(1) NOT NULL DEFAULT '0',
  `field_type` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп даних таблиці `site_vars`
--

INSERT INTO `site_vars` (`id`, `name`, `value`, `description`, `wysiwyg_on`, `field_type`) VALUES
(1, 'COUNTERS', '<script>\r\n  (function(i,s,o,g,r,a,m){i[''GoogleAnalyticsObject'']=r;i[r]=i[r]||function(){\r\n  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\r\n  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\r\n  })(window,document,''script'',''https://www.google-analytics.com/analytics.js'',''ga'');\r\n\r\nga(''create'', ''UA-82455529-1'', ''auto'');\r\nga(''send'', ''pageview'');\r\nga(''set'', ''userId'', {{USER_ID}});\r\n\r\n</script>', 'Счетчики статистики для сайта.', 0, 0),
(2, 'HEADER_LIKES', '', 'Код размещения лайков в конце <head>.', 0, 0),
(3, 'BODY_LIKES', '<div id="fb-root"></div>\r\n<script>(function(d, s, id) {\r\n  var js, fjs = d.getElementsByTagName(s)[0];\r\n  if (d.getElementById(id)) return;\r\n  js = d.createElement(s); js.id = id;\r\n  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.5&appId=189634737825719";\r\n  fjs.parentNode.insertBefore(js, fjs);\r\n}(document, ''script'', ''facebook-jssdk''));</script>', 'Код размещения лайков в начале <body>.', 0, 0),
(4, 'VIEW_LIKES', '<div class="fb-like" data-width="100" data-layout="button_count" data-action="like" data-show-faces="false" data-share="false"></div>', 'Код отображения лайков.', 0, 0),
(5, 'HOME_PROMO_GROUND', '20160709175359_682c0d7.jpg', 'Превью-изображение для блока «Земля» на главной странице.', 0, 3),
(6, 'HOME_PROMO_WATER', '20160709175406_586f634b204ac.jpg', 'Превью-изображение для блока «Вода» на главной странице.', 0, 3),
(7, 'HOME_PROMO_AIR', '20160709175411_8de2ac7024.jpg', 'Превью-изображение для блока «Воздух» на главной странице.', 0, 3);

-- --------------------------------------------------------

--
-- Структура таблиці `static_pages`
--

CREATE TABLE IF NOT EXISTS `static_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `url_name` tinytext NOT NULL,
  `menu_name` tinytext NOT NULL,
  `title` tinytext NOT NULL,
  `text` text NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text,
  `meta_keywords` text,
  `meta_image` varchar(255) DEFAULT NULL,
  `external_link` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп даних таблиці `static_pages`
--

INSERT INTO `static_pages` (`id`, `parent_id`, `url_name`, `menu_name`, `title`, `text`, `meta_title`, `meta_description`, `meta_keywords`, `meta_image`, `external_link`, `order`, `visible`) VALUES
(1, NULL, 'about', 'О компании', 'О компании', '<h1>О компании</h1><p>История компании</p>', '', '', '', NULL, '', 0, 1),
(2, NULL, 'how-it-works', 'How It Works', 'How It Works', '<p>How It Works</p>', '', '', '', NULL, '', 10, 1),
(3, NULL, 'payment-security', 'Payment Security', 'Payment Security', '<p>Payment Security</p>', '', '', '', NULL, '', 20, 1),
(4, NULL, 'rights', 'Rights & Conditions', 'Rights & Conditions', '<p>Rights &amp; Conditions</p>', '', '', '', NULL, '', 30, 1),
(5, NULL, 'cookies', 'Cookies', 'Cookies', '<p>Cookies</p>', '', '', '', NULL, '', 40, 1);

-- --------------------------------------------------------

--
-- Структура таблиці `subscribers`
--

CREATE TABLE IF NOT EXISTS `subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп даних таблиці `subscribers`
--

INSERT INTO `subscribers` (`id`, `name`, `email`, `date_created`) VALUES
(2, 'Vlad', 'Yogurt4587@gmail.com', '2016-08-23 14:52:37'),
(3, 'Hgg', 'Hghnnb@gmail.com', '2016-08-23 14:53:22'),
(4, 'ацуафвафв', 'titigj@gmail.com', '2016-08-24 11:20:21'),
(5, 'ориор', 'sddsfdf@gmail.com', '2016-08-26 15:46:30'),
(6, 'etertert', 'etetet@koko.co.il', '2016-08-26 15:48:21'),
(8, 'test', 'test@mail.ru', '2016-11-01 09:00:27');

-- --------------------------------------------------------

--
-- Структура таблиці `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `createtime` int(10) NOT NULL DEFAULT '0',
  `lastvisit` int(10) NOT NULL DEFAULT '0',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `social_identity` varchar(1000) DEFAULT NULL,
  `account` float(10,2) NOT NULL DEFAULT '0.00',
  `available_account` float(5,2) NOT NULL DEFAULT '0.00',
  `rating` float(5,2) NOT NULL DEFAULT '0.00',
  `parameter_1` float(5,2) NOT NULL DEFAULT '0.00',
  `parameter_2` float(5,2) NOT NULL DEFAULT '0.00',
  `parameter_3` float(5,2) NOT NULL DEFAULT '0.00',
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `decline_rating` int(11) NOT NULL DEFAULT '0',
  `first_complete` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=86 ;

--
-- Дамп даних таблиці `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `activkey`, `createtime`, `lastvisit`, `superuser`, `status`, `social_identity`, `account`, `available_account`, `rating`, `parameter_1`, `parameter_2`, `parameter_3`, `is_approved`, `decline_rating`, `first_complete`) VALUES
(1, 'project@mahaon.kiev.ua', 'e5c446a852f8ee3f902fb9bfbc320982', 'project@mahaon.kiev.ua', '9d3cda6377ba12c60f68eacde9271202', 1261146094, 1480680176, 1, 1, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 3),
(46, 'amerkushin@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'amerkushin@gmail.com', 'd9b8e3bffbef3639d22916327dff124b', 1474620582, 1487952866, 1, 1, 'FB1143873162301269 GP107741044290959792425', 0.00, 0.00, 5.00, 5.00, 5.00, 5.00, 1, 0, 3),
(47, 'yogurt4587@gmail.com', '623fcd3761e7dc71ac7784cc058e9dc9', 'yogurt4587@gmail.com', '0de86f4004a6e053c1c7cc5d4daee7e3', 1474721840, 1485601290, 1, 1, ' FB10209257300177651 GP100253729768317804614', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 3),
(50, 'alex.netlaw@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'alex.netlaw@gmail.com', 'b7a6adbf8fb3a5dd253ee3214d0da85c', 1474994733, 1475149502, 0, 1, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(51, 'dim2309@gmail.com', '001975bd479314efde870ea667a5b369', 'dim2309@gmail.com', 'facebook', 1475324130, 1476514044, 0, 1, 'FB10210627382065621', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(52, '911bplan@gmail.com', '322ce1301bc2539d4f256e7fcefbedb2', '911bplan@gmail.com', 'facebook', 1475737590, 1475737620, 0, 1, 'FB1181779198573462', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(53, 'melukandrew@gmail.com', '64840a186efb5fc61938ec8e2b3ee210', 'melukandrew@gmail.com', 'google', 1476283675, 1476352984, 0, 1, 'GP110427104352684422520', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(54, 'vitaliy.demyanenko.1991@gmail.com', '192fdec572e1aa63290fd86861139b61', 'vitaliy.demyanenko.1991@gmail.com', 'e791b5a69ed82c23acb15d1e5fcac160', 1476337783, 1476337903, 0, 1, 'FB1062437320541626', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(55, 'tivos92@mail.ru', 'b22c5005e63e60c882ab869bef463508', 'tivos92@mail.ru', 'facebook', 1476351650, 1477484441, 0, 1, 'FB1728806544108931', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(57, 'nikolkwa@yandex.ru', '48f715eb0627d04ca8d7739a2878a8a4', 'nikolkwa@yandex.ru', 'facebook', 1476883012, 1476883048, 0, 1, 'FB1165090180224676', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(59, 'yuracher@gmail.com', '25221ec2587acff531edf2a9a491443a', 'yuracher@gmail.com', 'facebook', 1477290931, 1477295334, 0, 1, 'FB1112307482150066', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(60, 'office@mahaon.kiev.ua', '1cd744a4b07d7968fb807c10d7d40cbd', 'office@mahaon.kiev.ua', 'google', 1477990908, 1478267885, 0, 1, 'GP104846112308504986523 FB358161834528628', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 3),
(61, 'dimitrishukfor@gmail.com', '01363b95cc802d0f7bfb9261457b5968', 'dimitrishukfor@gmail.com', 'google', 1477993252, 1477993370, 0, 1, 'GP107636946532459771976', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(63, 'soltanovka@gmail.com', '514c419ba6ed2113fc436bb28502790f', 'soltanovka@gmail.com', '20ef023764ffd20b0eea93084ea8a9a0', 1478249131, 1478271320, 0, 1, 'FB939646792834363', -432.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(64, 'mailbox@vkomlev.com', 'e10adc3949ba59abbe56e057f20f883e', 'mailbox@vkomlev.com', '55c493ead8bd9d00c3c1317d14a264c3', 1478680396, 1478681656, 0, 1, 'FB10204356152102511', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(71, 'myideum@gmail.com', '2d321b74176afd496ffdd4240de35f97', 'myideum@gmail.com', 'd997ef8126bda92b8a8088319f21f141', 1480746572, 1480748670, 0, 1, 'FB1242764082433169', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(72, 'test@test.com', '81dc9bdb52d04dc20036dbd8313ed055', 'test@test.com', '5f0e9ebbb830d165f241a94e1b14d1d7', 1480747279, 1487531670, 1, 1, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 1),
(73, 'xxiii@ukr.net', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'xxiii@ukr.net', 'efa6de48e7757846b5f3ca2d65b6aff5', 1481014832, 1481014937, 0, 1, 'FB1362058807172513', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(74, 'tipochok@meta.ua', '4ab01bc278c76b4085276fabc9c2cbba', 'tipochok@meta.ua', 'facebook', 1481127989, 1481132729, 0, 1, 'FB709274372568967', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(77, 'vti9999@yandex.ru', '827ccb0eea8a706c4c34a16891f84e7b', 'vti9999@yandex.ru', 'b870280f3244019e909bc1ff0ee7baad', 1485274775, 1485418154, 0, 1, NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 3),
(80, 'worontrans999@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'worontrans999@gmail.com', '6b53e38da40f1b816306457d86db6403', 1485600668, 1487322184, 0, 1, 'GP116607130519358725733', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(81, 'infokretivz.pro@gmail.com', '25f9e794323b453885f5181f1b624d0b', 'infokretivz.pro@gmail.com', '6ac8f34e69aa22e21e85b3fdb5f38409', 1485601889, 1485883393, 0, 1, 'GP117159992410881857630', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 3),
(83, 'getupway@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'getupway@gmail.com', '581dbb8e300157067d085d38a7da2f04', 1485602941, 1485603932, 0, 1, 'GP116420686537169185487', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 3),
(84, 'roma.f@mail.ru', '200820e3227815ed1756a6b531e7e0d2', 'roma.f@mail.ru', '04c573bbe3b42a71d9f9ed30d8f4990d', 1486918969, 1487360130, 0, 1, 'FB1157821844326869 GP112492436452454836640', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0),
(85, 'linkso5lru@gmail.com', 'c5fe25896e49ddfe996db7508cf00534', 'linkso5lru@gmail.com', 'f1df30ebd1cce27e48317a207dfb687d', 1487531693, 1487531706, 0, 1, 'GP116659697584666589441', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `user_addresses`
--

CREATE TABLE IF NOT EXISTS `user_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `province_id` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `zip` varchar(100) DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `lng` float DEFAULT NULL,
  `is_primary` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `province_id` (`province_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Дамп даних таблиці `user_addresses`
--

INSERT INTO `user_addresses` (`id`, `user_id`, `country_id`, `province_id`, `city`, `address`, `zip`, `lat`, `lng`, `is_primary`) VALUES
(25, 1, 232, NULL, 'Харьков', 'пр. Московский, 247', '', 49.9703, 36.3113, 0),
(26, 1, 232, NULL, 'Харьков', 'ул. Котлова, 29', '', 49.9962, 36.2118, 0),
(27, 46, 105, NULL, 'jerusalem', 'meksiko 6a', '9658113', 31.7587, 35.1692, 0),
(28, 46, 105, NULL, 'tel-aviv', 'herzel 4', '', 32.0665, 34.8491, 0),
(29, 47, 105, NULL, 'beit shemesh', 'aliya 11', '', 31.7512, 34.9875, 0),
(30, 47, 105, NULL, 'beit shemesh', '', '', 31.747, 34.9881, 0),
(31, 60, 4, NULL, '', '', '', -14.3016, -170.696, 0),
(32, 60, 73, NULL, 'Paris', '', '', 48.8566, 2.35222, 0),
(33, 60, 9, NULL, '', '', '', -38.4161, -63.6167, 0),
(34, 77, 3, NULL, '', '', '', 28.0339, 1.65963, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `user_documents`
--

CREATE TABLE IF NOT EXISTS `user_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `date_uploaded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `approved_by` int(11) DEFAULT NULL,
  `date_approved` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `approved_by` (`approved_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп даних таблиці `user_documents`
--

INSERT INTO `user_documents` (`id`, `user_id`, `title`, `filename`, `date_uploaded`, `is_approved`, `approved_by`, `date_approved`) VALUES
(1, 46, '111111', '20161006153743_d1bc407d302b8.docx', '2016-10-06 13:37:43', 1, 46, '2016-10-06 13:39:51'),
(3, 47, 'fsfsfsdfsdfs', '20161110143425_45dde134.doc', '2016-11-10 13:34:25', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `user_favourites`
--

CREATE TABLE IF NOT EXISTS `user_favourites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `offer_id` int(11) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `offer_id` (`offer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Дамп даних таблиці `user_favourites`
--

INSERT INTO `user_favourites` (`id`, `user_id`, `offer_id`, `date_added`) VALUES
(24, 46, 36, '2016-09-26 02:06:38'),
(27, 46, 35, '2016-09-26 02:07:58'),
(28, 46, 39, '2016-11-10 17:44:33'),
(30, 46, 34, '2016-11-23 07:57:56'),
(31, 72, 36, '2016-12-14 13:08:11');

-- --------------------------------------------------------

--
-- Структура таблиці `user_reviews`
--

CREATE TABLE IF NOT EXISTS `user_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `parameter_1` int(1) NOT NULL DEFAULT '0',
  `parameter_2` int(1) NOT NULL DEFAULT '0',
  `parameter_3` int(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблиці `user_reviews_marks`
--

CREATE TABLE IF NOT EXISTS `user_reviews_marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `review_id` (`review_id`),
  KEY `author_id` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблиці `withdraws`
--

CREATE TABLE IF NOT EXISTS `withdraws` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `payment_type` int(11) DEFAULT NULL,
  `amount` float(10,2) NOT NULL,
  `payer_name` varchar(255) DEFAULT NULL,
  `country` varchar(255) NOT NULL DEFAULT 'USA',
  `transfer_number` varchar(255) DEFAULT NULL,
  `log` text,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `approved_by` int(11) DEFAULT NULL,
  `date_approved` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `payment_type` (`payment_type`),
  KEY `approved_by` (`approved_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Обмеження зовнішнього ключа збережених таблиць
--

--
-- Обмеження зовнішнього ключа таблиці `list_provinces`
--
ALTER TABLE `list_provinces`
  ADD CONSTRAINT `list_provinces_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `list_countries` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offers`
--
ALTER TABLE `offers`
  ADD CONSTRAINT `offers_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `offers_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offers_addresses`
--
ALTER TABLE `offers_addresses`
  ADD CONSTRAINT `offers_addresses_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `offers_addresses_ibfk_2` FOREIGN KEY (`address_id`) REFERENCES `user_addresses` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offers_parameter_values`
--
ALTER TABLE `offers_parameter_values`
  ADD CONSTRAINT `offers_parameter_values_ibfk_1` FOREIGN KEY (`parameter_id`) REFERENCES `parameters` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `offers_parameter_values_ibfk_2` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offer_blocks`
--
ALTER TABLE `offer_blocks`
  ADD CONSTRAINT `offer_blocks_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offer_comments`
--
ALTER TABLE `offer_comments`
  ADD CONSTRAINT `offer_comments_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `offer_comments_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offer_documents`
--
ALTER TABLE `offer_documents`
  ADD CONSTRAINT `offer_documents_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `offer_documents_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Обмеження зовнішнього ключа таблиці `offer_faq`
--
ALTER TABLE `offer_faq`
  ADD CONSTRAINT `offer_faq_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offer_options`
--
ALTER TABLE `offer_options`
  ADD CONSTRAINT `offer_options_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offer_photos`
--
ALTER TABLE `offer_photos`
  ADD CONSTRAINT `offer_photos_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offer_reviews`
--
ALTER TABLE `offer_reviews`
  ADD CONSTRAINT `offer_reviews_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `offer_reviews_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `offer_review_photos`
--
ALTER TABLE `offer_review_photos`
  ADD CONSTRAINT `offer_review_photos_ibfk_1` FOREIGN KEY (`review_id`) REFERENCES `offer_reviews` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `ordered_options`
--
ALTER TABLE `ordered_options`
  ADD CONSTRAINT `ordered_options_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `ordered_options_ibfk_2` FOREIGN KEY (`option_id`) REFERENCES `offer_options` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`address_from`) REFERENCES `offers_addresses` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `orders_ibfk_4` FOREIGN KEY (`address_to`) REFERENCES `offers_addresses` (`id`) ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `parameters`
--
ALTER TABLE `parameters`
  ADD CONSTRAINT `parameters_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `parameter_groups` (`id`) ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `parameters_categories`
--
ALTER TABLE `parameters_categories`
  ADD CONSTRAINT `parameters_categories_ibfk_1` FOREIGN KEY (`parameter_id`) REFERENCES `parameters` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `parameters_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `parameter_values`
--
ALTER TABLE `parameter_values`
  ADD CONSTRAINT `parameter_values_ibfk_1` FOREIGN KEY (`parameter_id`) REFERENCES `parameters` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`payment_type`) REFERENCES `payment_types` (`id`),
  ADD CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `places`
--
ALTER TABLE `places`
  ADD CONSTRAINT `places_ibfk_1` FOREIGN KEY (`province_id`) REFERENCES `list_provinces` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `preoptions`
--
ALTER TABLE `preoptions`
  ADD CONSTRAINT `preoptions_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `private_messages`
--
ALTER TABLE `private_messages`
  ADD CONSTRAINT `private_messages_ibfk_1` FOREIGN KEY (`recepient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `private_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Обмеження зовнішнього ключа таблиці `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD CONSTRAINT `user_addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `user_addresses_ibfk_2` FOREIGN KEY (`province_id`) REFERENCES `list_provinces` (`id`);

--
-- Обмеження зовнішнього ключа таблиці `user_documents`
--
ALTER TABLE `user_documents`
  ADD CONSTRAINT `user_documents_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `user_documents_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Обмеження зовнішнього ключа таблиці `user_favourites`
--
ALTER TABLE `user_favourites`
  ADD CONSTRAINT `user_favourites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `user_favourites_ibfk_2` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `user_reviews`
--
ALTER TABLE `user_reviews`
  ADD CONSTRAINT `user_reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `user_reviews_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `user_reviews_marks`
--
ALTER TABLE `user_reviews_marks`
  ADD CONSTRAINT `user_reviews_marks_ibfk_1` FOREIGN KEY (`review_id`) REFERENCES `user_reviews` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `user_reviews_marks_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Обмеження зовнішнього ключа таблиці `withdraws`
--
ALTER TABLE `withdraws`
  ADD CONSTRAINT `withdraws_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `withdraws_ibfk_2` FOREIGN KEY (`payment_type`) REFERENCES `payment_types` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `withdraws_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
